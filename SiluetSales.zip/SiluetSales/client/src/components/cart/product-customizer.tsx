import { useState } from "react";
import { Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

interface ProductCustomizerProps {
  product: Product;
  onUpdate: (customization: ProductCustomization) => void;
  initialCustomization?: Partial<ProductCustomization>;
}

export interface ProductCustomization {
  size?: string;
  color: string;
  silhouettePosition: 'front' | 'side' | 'back';
  hasLipa: boolean;
  lipaText?: string;
  customerImage?: string;
  quantity: number;
}

export function ProductCustomizer({
  product,
  onUpdate,
  initialCustomization
}: ProductCustomizerProps) {
  const [customization, setCustomization] = useState<ProductCustomization>({
    color: initialCustomization?.color || product.defaultColor,
    silhouettePosition: initialCustomization?.silhouettePosition || 'front',
    hasLipa: initialCustomization?.hasLipa || false,
    quantity: initialCustomization?.quantity || 1,
    size: initialCustomization?.size,
    lipaText: initialCustomization?.lipaText,
    customerImage: initialCustomization?.customerImage,
  });

  const handleChange = (changes: Partial<ProductCustomization>) => {
    const updated = { ...customization, ...changes };
    setCustomization(updated);
    onUpdate(updated);
  };

  return (
    <div className="space-y-6">
      {/* Size Selection */}
      {product.sizes && product.sizes.length > 0 && (
        <div className="space-y-2">
          <Label>Ölçü</Label>
          <RadioGroup
            value={customization.size}
            onValueChange={(size) => handleChange({ size })}
            className="grid grid-cols-3 gap-2"
          >
            {product.sizes.map((size) => (
              <div key={size}>
                <RadioGroupItem
                  value={size}
                  id={`size-${size}`}
                  className="peer sr-only"
                />
                <Label
                  htmlFor={`size-${size}`}
                  className={cn(
                    "flex items-center justify-center rounded-md border-2 border-muted p-2 hover:bg-muted peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary",
                  )}
                >
                  {size}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </div>
      )}

      {/* Color Selection */}
      <div className="space-y-2">
        <Label>Rəng</Label>
        <RadioGroup
          value={customization.color}
          onValueChange={(color) => handleChange({ color })}
          className="grid grid-cols-3 gap-2"
        >
          {product.colors.map((color) => (
            <div key={color.name}>
              <RadioGroupItem
                value={color.name}
                id={`color-${color.name}`}
                className="peer sr-only"
                disabled={!color.isAvailable}
              />
              <Label
                htmlFor={`color-${color.name}`}
                className={cn(
                  "flex items-center justify-center rounded-md border-2 border-muted p-2 hover:bg-muted peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary",
                  !color.isAvailable && "opacity-50 cursor-not-allowed"
                )}
              >
                {color.name} {color.price > 0 && `(+${color.price} AZN)`}
              </Label>
            </div>
          ))}
        </RadioGroup>
      </div>

      {/* Position Selection */}
      <div className="space-y-2">
        <Label>Görünüş</Label>
        <RadioGroup
          value={customization.silhouettePosition}
          onValueChange={(position) => 
            handleChange({ silhouettePosition: position as 'front' | 'side' | 'back' })
          }
          className="grid grid-cols-3 gap-2"
        >
          {product.silhouettePositions.map((position) => (
            <div key={position}>
              <RadioGroupItem
                value={position}
                id={`position-${position}`}
                className="peer sr-only"
              />
              <Label
                htmlFor={`position-${position}`}
                className={cn(
                  "flex items-center justify-center rounded-md border-2 border-muted p-2 hover:bg-muted peer-data-[state=checked]:border-primary peer-data-[state=checked]:text-primary",
                )}
              >
                {position === 'front' ? 'Öndən' :
                 position === 'side' ? 'Yandan' : 'Arxadan'}
              </Label>
            </div>
          ))}
        </RadioGroup>
      </div>

      {/* Lipa Option */}
      {product.hasLipa && (
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch
              id="lipa"
              checked={customization.hasLipa}
              onCheckedChange={(checked) => handleChange({ hasLipa: checked })}
            />
            <Label htmlFor="lipa">
              Lipa əlavə et {product.lipaPrice && `(+${product.lipaPrice} AZN)`}
            </Label>
          </div>
          
          {customization.hasLipa && (
            <div className="space-y-2">
              <Label htmlFor="lipa-text">Lipa mətni</Label>
              <Input
                id="lipa-text"
                value={customization.lipaText || ''}
                onChange={(e) => handleChange({ lipaText: e.target.value })}
                placeholder="Lipa mətni daxil edin"
              />
            </div>
          )}
        </div>
      )}

      {/* Image Upload */}
      {product.requiresImage && (
        <div className="space-y-2">
          <Label htmlFor="customer-image">Şəkil</Label>
          <Input
            id="customer-image"
            type="file"
            accept="image/*"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                const reader = new FileReader();
                reader.onloadend = () => {
                  handleChange({ customerImage: reader.result as string });
                };
                reader.readAsDataURL(file);
              }
            }}
          />
        </div>
      )}

      {/* Quantity */}
      <div className="space-y-2">
        <Label htmlFor="quantity">Miqdar</Label>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => 
              handleChange({ 
                quantity: Math.max(1, customization.quantity - 1) 
              })
            }
          >
            -
          </Button>
          <Input
            id="quantity"
            type="number"
            min="1"
            value={customization.quantity}
            onChange={(e) => 
              handleChange({ quantity: Math.max(1, parseInt(e.target.value) || 1) })
            }
            className="w-20 text-center"
          />
          <Button
            variant="outline"
            size="icon"
            onClick={() => 
              handleChange({ quantity: customization.quantity + 1 })
            }
          >
            +
          </Button>
        </div>
      </div>
    </div>
  );
}
