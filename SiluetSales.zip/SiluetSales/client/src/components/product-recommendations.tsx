import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/use-cart";
import { useToast } from "@/hooks/use-toast";

export function ProductRecommendations() {
  const { toast } = useToast();
  const { addToCart } = useCart();

  const { data: recommendations, isLoading, error } = useQuery<Product[]>({
    queryKey: ['/api/recommendations'],
  });

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="bg-muted">
            <CardHeader className="h-24" />
            <CardContent className="h-32" />
          </Card>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <Card className="border-destructive">
        <CardHeader>
          <CardTitle className="text-destructive">Xəta</CardTitle>
          <CardDescription>
            Tövsiyələr alınarkən xəta baş verdi. Zəhmət olmasa bir az sonra yenidən cəhd edin.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (!recommendations?.length) {
    return null;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Sparkles className="h-5 w-5 text-yellow-500" />
        <h2 className="text-2xl font-bold">Sizin üçün Tövsiyələr</h2>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {recommendations.map((product) => (
          <Card key={product.id} className="group relative overflow-hidden transition-all hover:shadow-lg">
            <CardHeader>
              <CardTitle>{product.name}</CardTitle>
              <CardDescription>{product.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-lg font-semibold">
                  {product.basePrice} AZN
                </span>
                <Button
                  onClick={() => {
                    addToCart(product, 1);
                    toast({
                      title: "Məhsul əlavə edildi",
                      description: `${product.name} səbətə əlavə edildi.`
                    });
                  }}
                >
                  Səbətə əlavə et
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}