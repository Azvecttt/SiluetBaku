import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";

export function BackToMenu() {
  const [_, setLocation] = useLocation();

  return (
    <Button
      variant="outline"
      className="fixed top-4 left-4 z-50"
      onClick={() => setLocation("/")}
    >
      <ArrowLeft className="mr-2 h-4 w-4" />
      Menyuya qayıt
    </Button>
  );
}
