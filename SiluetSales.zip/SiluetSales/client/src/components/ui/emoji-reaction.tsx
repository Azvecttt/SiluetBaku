import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "./button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import type { EmojiReaction } from "@shared/schema";

const EMOJI_OPTIONS = ["👍", "❤️", "😊", "🌟", "👏"];

interface EmojiReactionsProps {
  productId: number;
}

export function EmojiReactions({ productId }: EmojiReactionsProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedEmoji, setSelectedEmoji] = useState<string | null>(null);

  const { data: reactions = [] } = useQuery<EmojiReaction[]>({
    queryKey: ["/api/reactions", productId],
  });

  const addReactionMutation = useMutation({
    mutationFn: async (emoji: string) => {
      const res = await apiRequest("POST", "/api/reactions", {
        productId,
        emoji,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reactions", productId] });
      toast({
        title: "Reaksiya əlavə edildi",
        description: "Məhsula reaksiyanız uğurla əlavə edildi",
      });
    },
  });

  const removeReactionMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/reactions/${productId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reactions", productId] });
      setSelectedEmoji(null);
      toast({
        title: "Reaksiya silindi",
        description: "Məhsula reaksiyanız uğurla silindi",
      });
    },
  });

  // Get counts for each emoji
  const getEmojiCounts = () => {
    const counts: Record<string, number> = {};
    reactions.forEach((reaction) => {
      counts[reaction.emoji] = (counts[reaction.emoji] || 0) + 1;
    });
    return counts;
  };

  // Check if current user has reacted
  const userReaction = reactions.find((r) => r.userId === user?.id);

  const handleEmojiClick = (emoji: string) => {
    if (!user) {
      toast({
        title: "Giriş tələb olunur",
        description: "Reaksiya bildirmək üçün daxil olmalısınız",
        variant: "destructive",
      });
      return;
    }

    if (userReaction) {
      removeReactionMutation.mutate();
    } else {
      addReactionMutation.mutate(emoji);
      setSelectedEmoji(emoji);
    }
  };

  const emojiCounts = getEmojiCounts();

  return (
    <div className="flex gap-2 items-center">
      {EMOJI_OPTIONS.map((emoji) => (
        <Button
          key={emoji}
          variant="ghost"
          size="sm"
          className={`hover:bg-primary/10 ${
            userReaction?.emoji === emoji ? "bg-primary/20" : ""
          }`}
          onClick={() => handleEmojiClick(emoji)}
        >
          <span className="text-lg mr-1">{emoji}</span>
          <span className="text-sm">{emojiCounts[emoji] || 0}</span>
        </Button>
      ))}
    </div>
  );
}
