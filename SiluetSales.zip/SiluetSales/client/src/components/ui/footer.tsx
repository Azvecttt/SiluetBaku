import { FaInstagram, FaTiktok, FaTelegram } from "react-icons/fa";

export function Footer() {
  return (
    <footer className="bg-white border-t">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col items-center space-y-4">
          <div className="flex space-x-6">
            <a
              href="https://instagram.com/siluetbaku"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-gray-600"
            >
              <FaInstagram className="w-6 h-6" />
            </a>
            <a
              href="https://tiktok.com/@siluetbaku"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-gray-600"
            >
              <FaTiktok className="w-6 h-6" />
            </a>
            <a
              href="https://t.me/siluetbaku_bot"
              target="_blank"
              rel="noopener noreferrer"
              className="text-gray-500 hover:text-gray-600"
            >
              <FaTelegram className="w-6 h-6" />
            </a>
          </div>
          <div className="text-center">
            <p className="text-gray-500">
              © {new Date().getFullYear()} SiluetBaku. Bütün hüquqlar qorunur.
            </p>
            <p className="text-gray-400 text-sm mt-1">
              Ünvan: Bakı şəhəri
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
