import { Notification } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "./card";
import { Bell, Calendar, Share2, Gift } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export function NotificationList() {
  const { data: notifications = [] } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
  });

  const getIcon = (type: string) => {
    switch (type) {
      case 'ORDER':
        return <Calendar className="w-5 h-5 text-primary" />;
      case 'SOCIAL':
        return <Share2 className="w-5 h-5 text-primary" />;
      case 'REWARD':
        return <Gift className="w-5 h-5 text-primary" />;
      default:
        return <Bell className="w-5 h-5 text-primary" />;
    }
  };

  if (notifications.length === 0) {
    return (
      <div className="text-center text-muted-foreground p-4">
        Heç bir bildiriş yoxdur
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {notifications.map((notification) => (
        <Card key={notification.id}>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              {getIcon(notification.type)}
              <div className="flex-1">
                <p className="font-medium">{notification.content}</p>
                <p className="text-sm text-muted-foreground">
                  {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
