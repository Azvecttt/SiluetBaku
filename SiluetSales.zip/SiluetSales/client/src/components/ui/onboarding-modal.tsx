import { useState, useEffect } from "react";
import { Dialog, DialogContent } from "./dialog";
import { Card, CardContent } from "./card";
import { Button } from "./button";
import { Progress } from "./progress";
import { Trophy, Gift, Star, ArrowRight, Check, User, ShoppingBag, Share2 } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { OnboardingStep, Reward } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import confetti from 'canvas-confetti';
import { useAuth } from "@/hooks/use-auth";

interface OnboardingModalProps {
  open: boolean;
  onClose: () => void;
}

export function OnboardingModal({ open, onClose }: OnboardingModalProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: steps = [] } = useQuery<OnboardingStep[]>({
    queryKey: ["/api/onboarding/steps"],
    enabled: open,
  });

  const { data: userProgress = [] } = useQuery<Array<{ stepId: number; completed: boolean }>>({
    queryKey: ["/api/onboarding/progress"],
    enabled: open,
  });

  const { data: rewards = [] } = useQuery<Reward[]>({
    queryKey: ["/api/rewards"],
    enabled: open,
  });

  const updateProgressMutation = useMutation({
    mutationFn: async (stepId: number) => {
      const res = await apiRequest("POST", `/api/onboarding/progress/${stepId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/onboarding/progress"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });

      // Trigger confetti animation
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });

      toast({
        title: "Təbriklər! 🎉",
        description: "Növbəti mərhələni tamamladınız və xal qazandınız!",
      });
    },
  });

  const completedSteps = userProgress.filter(p => p.completed).length;
  const progress = steps.length > 0 ? (completedSteps / steps.length) * 100 : 0;

  const getStepIcon = (iconName: string) => {
    switch (iconName) {
      case "User":
        return <User className="w-8 h-8 mx-auto" />;
      case "ShoppingBag":
        return <ShoppingBag className="w-8 h-8 mx-auto" />;
      case "Share2":
        return <Share2 className="w-8 h-8 mx-auto" />;
      case "Trophy":
        return <Trophy className="w-8 h-8 mx-auto" />;
      case "Gift":
        return <Gift className="w-8 h-8 mx-auto" />;
      case "Star":
        return <Star className="w-8 h-8 mx-auto" />;
      default:
        return <Star className="w-8 h-8 mx-auto" />;
    }
  };

  const handleNext = async () => {
    try {
      const currentStepData = steps[currentStep];
      if (!currentStepData) return;

      await updateProgressMutation.mutateAsync(currentStepData.id);

      if (currentStep < steps.length - 1) {
        setCurrentStep(prev => prev + 1);
      } else {
        // All steps completed
        onClose();
      }
    } catch (error) {
      console.error('Error updating progress:', error);
      toast({
        title: "Xəta",
        description: "Xal qazanma prosesində xəta baş verdi",
        variant: "destructive",
      });
    }
  };

  // Reset currentStep when modal opens
  useEffect(() => {
    if (open) {
      setCurrentStep(0);
    }
  }, [open]);

  const isStepCompleted = (stepId: number) => {
    return userProgress.some(p => p.stepId === stepId && p.completed);
  };

  const currentStepCompleted = currentStep < steps.length && 
    isStepCompleted(steps[currentStep]?.id);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <div className="space-y-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              SiluetBaku-ya Xoş Gəlmisiniz! 🎉
            </h2>
            <p className="text-muted-foreground mt-2">
              Mükafatlar qazanmaq üçün əsas xüsusiyyətləri kəşf edin
            </p>
          </div>

          <div className="relative">
            <Progress value={progress} className="h-2" />
            <span className="absolute right-0 top-4 text-sm text-muted-foreground">
              {completedSteps}/{steps.length} tamamlandı
            </span>
          </div>

          <div className="grid grid-cols-3 gap-4">
            {steps.map((step, index) => (
              <Card
                key={step.id}
                className={cn(
                  "relative cursor-pointer transition-all hover:shadow-md",
                  index === currentStep && "ring-2 ring-primary",
                  isStepCompleted(step.id) && "bg-secondary/20"
                )}
                onClick={() => setCurrentStep(index)}
              >
                <CardContent className="p-4 text-center">
                  {isStepCompleted(step.id) && (
                    <div className="absolute -top-2 -right-2 bg-primary rounded-full p-1">
                      <Check className="w-4 h-4 text-primary-foreground" />
                    </div>
                  )}
                  <div className="mb-2">
                    {getStepIcon(step.icon)}
                  </div>
                  <h3 className="font-semibold">{step.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {step.points} xal
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    {step.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="border rounded-lg p-4 bg-secondary/5">
            <h3 className="font-semibold mb-2 flex items-center gap-2">
              <Gift className="w-5 h-5 text-primary" />
              Mükafatlar
            </h3>
            <div className="grid grid-cols-2 gap-4">
              {rewards.map((reward) => (
                <div
                  key={reward.id}
                  className="flex items-center gap-2 p-3 rounded-md bg-background shadow-sm border"
                >
                  {reward.icon === "Percent" ? (
                    <span className="text-lg font-bold text-primary">%</span>
                  ) : (
                    <Gift className="w-5 h-5 text-primary" />
                  )}
                  <div>
                    <p className="font-medium">{reward.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {reward.pointsRequired} xal tələb olunur
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              Hər addımı tamamlayaraq xal qazanın
            </p>
            <Button 
              onClick={handleNext}
              disabled={updateProgressMutation.isPending || currentStepCompleted}
              className="relative overflow-hidden group"
            >
              <span className="relative z-10">
                {currentStep < steps.length - 1 ? (
                  <>
                    Növbəti
                    <ArrowRight className="w-4 h-4 ml-2 inline-block transition-transform group-hover:translate-x-1" />
                  </>
                ) : (
                  "Tamamla"
                )}
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/10 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}