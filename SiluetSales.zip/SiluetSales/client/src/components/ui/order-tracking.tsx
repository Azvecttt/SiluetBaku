import { useQuery } from "@tanstack/react-query";
import { Order, OrderTracking } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Timeline, TimelineItem } from "./timeline";
import { Map } from "./map";
import { format } from "date-fns";

interface OrderTrackingProps {
  orderId: number;
}

export function OrderTracking({ orderId }: OrderTrackingProps) {
  const { data: order } = useQuery<Order>({
    queryKey: ["/api/orders", orderId],
  });

  const { data: tracking } = useQuery<OrderTracking[]>({
    queryKey: ["/api/orders", orderId, "tracking"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (!order || !tracking) {
    return null;
  }

  const latestLocation = tracking[tracking.length - 1]?.location;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sifariş İzləmə</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <Timeline>
              {tracking.map((track) => (
                <TimelineItem
                  key={track.id}
                  title={track.status}
                  description={track.notes}
                  timestamp={format(new Date(track.timestamp), "dd MMM yyyy HH:mm")}
                />
              ))}
            </Timeline>
          </div>
          {latestLocation && (
            <div className="h-[300px]">
              <Map
                center={[latestLocation.lat, latestLocation.lng]}
                marker={latestLocation}
              />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
