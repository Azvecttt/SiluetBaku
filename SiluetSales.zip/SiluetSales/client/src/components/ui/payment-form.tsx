import { loadStripe } from "@stripe/stripe-js";
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";
import { FaApplePay } from "react-icons/fa";
import { Button } from "./button";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogTrigger } from "./dialog";

// Initialize Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

interface PaymentFormProps {
  amount: number;
  onSuccess: () => void;
}

function StripeCheckoutForm({ amount, onSuccess }: PaymentFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/payment-success`,
        },
      });

      if (error) {
        toast({
          title: "Ödəniş xətası",
          description: "Xahiş edirik test kartı istifadə edin:\n4242 4242 4242 4242\nTarix: Gələcək tarix\nCVC: İstənilən 3 rəqəm",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Ödəniş uğurlu oldu!",
          description: "Sifarişiniz qəbul edildi.",
        });
        onSuccess();
      }
    } catch (error) {
      toast({
        title: "Ödəniş xətası",
        description: "Test kartı istifadə edin: 4242 4242 4242 4242",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="bg-muted p-4 rounded-lg mb-4">
        <p className="text-sm text-muted-foreground mb-2">Test üçün bu kart məlumatlarını istifadə edin:</p>
        <ul className="text-sm space-y-1">
          <li>Kart nömrəsi: 4242 4242 4242 4242</li>
          <li>Son istifadə tarixi: Gələcək hər hansı bir tarix</li>
          <li>CVC: İstənilən 3 rəqəm</li>
        </ul>
      </div>
      <PaymentElement />
      <Button
        type="submit"
        className="w-full"
        disabled={isProcessing || !stripe || !elements}
      >
        {isProcessing ? "Proses gedir..." : "Ödəniş et"}
      </Button>
    </form>
  );
}

export function PaymentForm({ amount, onSuccess }: PaymentFormProps) {
  const [clientSecret, setClientSecret] = useState<string>();
  const [canMakePayment, setCanMakePayment] = useState(false);
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    async function initializePayment() {
      try {
        const response = await apiRequest("POST", "/api/payments/create-payment-intent", { amount });
        const { clientSecret } = await response.json();
        setClientSecret(clientSecret);
      } catch (error) {
        toast({
          title: "Xəta",
          description: "Ödəniş prosesini başlatmaq mümkün olmadı. Zəhmət olmasa yenidən cəhd edin.",
          variant: "destructive",
        });
      }
    }

    if (isOpen) {
      initializePayment();
    }
  }, [amount, isOpen]);

  // Check Apple Pay availability
  useEffect(() => {
    async function checkApplePayAvailability() {
      if (!stripePromise) return;

      const stripe = await stripePromise;
      if (!stripe) return;

      const paymentRequest = stripe.paymentRequest({
        country: 'US',
        currency: 'usd',
        total: {
          label: 'SiluetBaku Sifariş',
          amount: amount * 100,
        },
        requestPayerName: true,
        requestPayerEmail: true,
      });

      // Check if Apple Pay is available
      const result = await paymentRequest.canMakePayment();
      setCanMakePayment(!!result?.applePay);
    }

    checkApplePayAvailability();
  }, [amount]);

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="w-full">Ödəniş et</Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <div className="space-y-6 p-4">
          <div className="text-lg font-semibold text-center mb-4">Ödəniş üsulu:</div>

          {canMakePayment && (
            <>
              <Button
                variant="outline"
                className="w-full h-auto py-4 flex items-center justify-center gap-2"
                onClick={() => {
                  toast({
                    title: "Test rejimi",
                    description: "Apple Pay test rejimində aktiv deyil. Xahiş edirik test kartı ilə ödəniş edin.",
                  });
                }}
              >
                <FaApplePay className="w-8 h-8" />
                Apple Pay ilə ödəniş
              </Button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-background text-muted-foreground">və ya</span>
                </div>
              </div>
            </>
          )}

          {clientSecret && (
            <Elements stripe={stripePromise} options={{ 
              clientSecret, 
              appearance: { theme: 'stripe' }
            }}>
              <StripeCheckoutForm amount={amount} onSuccess={onSuccess} />
            </Elements>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}