import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "./card";
import { Button } from "./button";
import { ShoppingBag } from "lucide-react";
import { Product } from "@shared/schema";
import { useCart } from "@/hooks/use-cart";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogTrigger } from "./dialog";
import { ProductCustomization } from "./product-customization";
import { motion } from "framer-motion";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [isCustomizing, setIsCustomizing] = useState(false);

  const handleCustomizationComplete = (customization: ProductCustomization) => {
    addToCart(product, 1, customization.size, customization.hasLipa, {
      view: customization.view,
      notes: customization.notes,
      customerImage: customization.customerImage,
    });
    setIsCustomizing(false);
    toast({
      title: "Məhsul səbətə əlavə edildi",
      description: "Sifarişi tamamlamaq üçün səbətə keçin",
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      <Card className="group bg-black/50 border border-white/10 hover:border-primary/50 transition-all duration-300">
        <CardHeader>
          {product.images && product.images.length > 0 && (
            <div className="relative overflow-hidden rounded-lg">
              <img
                src={product.images[0]}
                alt={product.name}
                className="w-full h-64 object-cover transform group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
          )}
          <CardTitle className="text-xl mt-4 group-hover:text-primary transition-colors">
            {product.name}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-white/60">{product.description}</p>
          <p className="text-2xl font-bold mt-4 text-primary">
            {product.basePrice} AZN
          </p>
          {product.hasLipa && (
            <p className="text-sm text-white/40">
              +{product.lipaPrice} AZN lipa üçün
            </p>
          )}
        </CardContent>
        <CardFooter className="pt-4">
          <Dialog open={isCustomizing} onOpenChange={setIsCustomizing}>
            <DialogTrigger asChild>
              <Button
                className="w-full bg-white/10 hover:bg-primary text-white border border-white/20 hover:border-primary group"
              >
                <ShoppingBag className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
                Səbətə əlavə et
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <ProductCustomization
                product={product}
                onCustomizationComplete={handleCustomizationComplete}
              />
            </DialogContent>
          </Dialog>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
