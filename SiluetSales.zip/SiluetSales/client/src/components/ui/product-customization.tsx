
import { useState } from "react";
import { Product } from "@shared/schema";
import { Button } from "./button";
import { Label } from "./label";
import { Input } from "./input";
import { RadioGroup, RadioGroupItem } from "./radio-group";
import { Switch } from "./switch";

interface ProductCustomizationProps {
  product: Product;
  onSubmit: (customization: {
    size?: string;
    color: string;
    hasLipa: boolean;
    lipaText?: string;
    customerImage?: string;
    quantity: number;
  }) => void;
}

export function ProductCustomization({ product, onSubmit }: ProductCustomizationProps) {
  const [size, setSize] = useState<string>(product.sizes?.[0] || "");
  const [color, setColor] = useState<string>(product.colors[0]?.name || product.defaultColor);
  const [hasLipa, setHasLipa] = useState(false);
  const [lipaText, setLipaText] = useState("");
  const [customerImage, setCustomerImage] = useState<string>();
  const [quantity, setQuantity] = useState(1);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCustomerImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      size,
      color,
      hasLipa,
      lipaText: hasLipa ? lipaText : undefined,
      customerImage,
      quantity,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {product.sizes && product.sizes.length > 0 && (
        <div className="space-y-2">
          <Label>Ölçü</Label>
          <RadioGroup value={size} onValueChange={setSize}>
            {product.sizes.map((s) => (
              <div key={s} className="flex items-center space-x-2">
                <RadioGroupItem value={s} id={`size-${s}`} />
                <Label htmlFor={`size-${s}`}>{s}</Label>
              </div>
            ))}
          </RadioGroup>
        </div>
      )}

      <div className="space-y-2">
        <Label>Rəng</Label>
        <RadioGroup value={color} onValueChange={setColor}>
          {product.colors.map((c) => (
            <div key={c.name} className="flex items-center space-x-2">
              <RadioGroupItem value={c.name} id={`color-${c.name}`} disabled={!c.isAvailable} />
              <Label htmlFor={`color-${c.name}`}>
                {c.name} {c.price > 0 ? `(+${c.price} AZN)` : ''}
              </Label>
            </div>
          ))}
        </RadioGroup>
      </div>

      {product.hasLipa && (
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Switch
              id="lipa"
              checked={hasLipa}
              onCheckedChange={setHasLipa}
            />
            <Label htmlFor="lipa">Lipa (+{product.lipaPrice} AZN)</Label>
          </div>
          {hasLipa && (
            <Input
              placeholder="Lipa yazısı"
              value={lipaText}
              onChange={(e) => setLipaText(e.target.value)}
            />
          )}
        </div>
      )}

      {product.requiresImage && (
        <div className="space-y-2">
          <Label>Şəkil</Label>
          <Input
            type="file"
            accept="image/*"
            onChange={handleImageChange}
          />
        </div>
      )}

      <div className="space-y-2">
        <Label>Miqdar</Label>
        <Input
          type="number"
          min="1"
          value={quantity}
          onChange={(e) => setQuantity(parseInt(e.target.value))}
        />
      </div>

      <Button type="submit" className="w-full">
        Səbətə əlavə et
      </Button>
    </form>
  );
}
