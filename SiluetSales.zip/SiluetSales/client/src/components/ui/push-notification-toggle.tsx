import { Switch } from "./switch";
import { Label } from "./label";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export function PushNotificationToggle() {
  const [subscription, setSubscription] = useState<PushSubscription | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Check if Push notification is supported
    if (!("Notification" in window) || !("serviceWorker" in navigator)) {
      return;
    }

    // Check existing subscription
    navigator.serviceWorker.ready.then(registration => {
      registration.pushManager.getSubscription().then(setSubscription);
    });
  }, []);

  const subscribeToPushNotifications = async () => {
    try {
      const registration = await navigator.serviceWorker.ready;
      
      // Get VAPID public key from server
      const response = await fetch("/api/notifications/vapid-public-key");
      const { publicKey } = await response.json();

      // Subscribe to push notifications
      const pushSubscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: publicKey
      });

      // Send subscription to server
      await apiRequest("POST", "/api/notifications/subscribe", pushSubscription);

      setSubscription(pushSubscription);
      
      toast({
        title: "Bildirişlər aktivləşdirildi",
        description: "İndi siz push bildirişləri alacaqsınız",
      });
    } catch (error) {
      toast({
        title: "Xəta",
        description: "Bildirişləri aktivləşdirmək mümkün olmadı",
        variant: "destructive",
      });
    }
  };

  const unsubscribeFromPushNotifications = async () => {
    try {
      if (subscription) {
        await subscription.unsubscribe();
        await apiRequest("DELETE", "/api/notifications/subscribe");
        setSubscription(null);
        
        toast({
          title: "Bildirişlər deaktiv edildi",
          description: "Artıq push bildirişləri almayacaqsınız",
        });
      }
    } catch (error) {
      toast({
        title: "Xəta",
        description: "Bildirişləri deaktiv etmək mümkün olmadı",
        variant: "destructive",
      });
    }
  };

  if (!("Notification" in window) || !("serviceWorker" in navigator)) {
    return null;
  }

  return (
    <div className="flex items-center space-x-2">
      <Switch
        id="push-notifications"
        checked={!!subscription}
        onCheckedChange={(checked) => {
          if (checked) {
            subscribeToPushNotifications();
          } else {
            unsubscribeFromPushNotifications();
          }
        }}
      />
      <Label htmlFor="push-notifications">Push bildirişləri</Label>
    </div>
  );
}
