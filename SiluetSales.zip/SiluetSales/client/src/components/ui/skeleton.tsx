import { cn } from "@/lib/utils"
import { motion } from "framer-motion"

interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "rectangular" | "circular" | "text"
  width?: string | number
  height?: string | number
}

function Skeleton({
  className,
  variant = "rectangular",
  width,
  height,
  ...props
}: SkeletonProps) {
  const baseStyles = "relative overflow-hidden bg-muted/50"
  const variantStyles = {
    rectangular: "rounded-md",
    circular: "rounded-full",
    text: "rounded h-4",
  }

  return (
    <div
      className={cn(baseStyles, variantStyles[variant], className)}
      style={{ width, height }}
      {...props}
    >
      <motion.div
        className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/10 to-transparent"
        animate={{ translateX: ["0%", "200%"] }}
        transition={{
          duration: 1.5,
          repeat: Infinity,
          ease: "linear",
        }}
      />
    </div>
  )
}

// Predefined skeleton layouts
function ProductCardSkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton height={250} className="w-full" />
      <Skeleton width={200} variant="text" />
      <Skeleton width={100} variant="text" />
      <Skeleton height={36} className="w-full mt-4" />
    </div>
  )
}

function ProfileSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Skeleton variant="circular" width={48} height={48} />
        <div className="space-y-2">
          <Skeleton variant="text" width={200} />
          <Skeleton variant="text" width={150} />
        </div>
      </div>
      <div className="space-y-4">
        <Skeleton height={60} className="w-full" />
        <Skeleton height={60} className="w-full" />
        <Skeleton height={60} className="w-full" />
      </div>
    </div>
  )
}

export { Skeleton, ProductCardSkeleton, ProfileSkeleton }