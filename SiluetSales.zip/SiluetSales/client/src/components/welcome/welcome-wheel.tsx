
import { useState } from "react";
import { motion, useAnimation } from "framer-motion";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/api";
import { Card } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import confetti from "canvas-confetti";

const SPIN_DURATION = 5000;
const SPIN_ROUNDS = 5;

interface WelcomeWheelProps {
  onComplete: () => void;
}

export function WelcomeWheel({ onComplete }: WelcomeWheelProps) {
  const [isSpinning, setIsSpinning] = useState(false);
  const controls = useAnimation();
  const { toast } = useToast();

  const spinMutation = useMutation({
    mutationFn: () => apiRequest("/api/welcome-rewards/spin", {
      method: "POST"
    }),
    onSuccess: (data) => {
      setTimeout(() => {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 }
        });

        let message = "";
        switch (data.rewardType) {
          case "discount":
            message = `${data.discountPercentage}% endirim`;
            break;
          case "free_shipping":
            message = "Pulsuz çatdırılma";
            break;
          case "free_gift_wrap":
            message = "Pulsuz hədiyyəlik paketləmə";
            break;
          case "free_lipa":
            message = "Pulsuz lipa";
            break;
        }

        toast({
          title: "Təbrik edirik!",
          description: `${message} qazandınız! Bu bonus 3 gün müddətində etibarlıdır.`
        });

        onComplete();
      }, SPIN_DURATION);
    },
    onError: (error) => {
      toast({
        title: "Xəta baş verdi",
        description: error instanceof Error ? error.message : "Bonus alınmadı",
        variant: "destructive"
      });
    }
  });

  const handleSpin = async () => {
    if (isSpinning) return;
    
    setIsSpinning(true);
    const finalAngle = 360 * SPIN_ROUNDS + Math.random() * 360;
    
    await controls.start({
      rotate: finalAngle,
      transition: {
        duration: SPIN_DURATION / 1000,
        ease: "circOut"
      }
    });

    spinMutation.mutate();
  };

  const sections = [
    "10%", "Pulsuz çatdırılma", "15%", "Pulsuz lipa",
    "25%", "Pulsuz paketləmə", "35%", "Pulsuz çatdırılma"
  ];

  return (
    <Card className="p-6 max-w-md mx-auto text-center">
      <h2 className="text-2xl font-bold mb-4">Xoş gəldiniz!</h2>
      <p className="mb-6">
        Çarxı fırladaraq bonus qazanın!
        <br />
        <small className="text-muted-foreground">
          (Endirimlər və hədiyyələr 3 gün ərzində etibarlıdır)
        </small>
      </p>

      <div className="relative w-64 h-64 mx-auto mb-6">
        <motion.div
          className="absolute inset-0 rounded-full border-4 border-primary"
          style={{ 
            backgroundImage: `conic-gradient(from 0deg, ${
              sections.map((_, i) => 
                `${i % 2 ? 'hsl(var(--primary))' : 'hsl(var(--muted))'} ${i * (360/sections.length)}deg ${(i + 1) * (360/sections.length)}deg`
              ).join(', ')
            })`
          }}
          animate={controls}
        >
          {sections.map((section, i) => (
            <div
              key={i}
              className="absolute w-full h-full flex items-center justify-center"
              style={{
                transform: `rotate(${i * (360/sections.length) + (360/sections.length/2)}deg)`,
              }}
            >
              <span className="text-sm font-bold text-white transform -rotate-90">
                {section}
              </span>
            </div>
          ))}
        </motion.div>
        
        <div className="absolute inset-0 flex items-center justify-center">
          <button
            onClick={handleSpin}
            disabled={isSpinning}
            className="bg-primary text-primary-foreground hover:bg-primary/90 px-6 py-3 rounded-full font-bold shadow-lg transform transition-transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSpinning ? "Fırlanır..." : "Fırlat"}
          </button>
        </div>
      </div>
    </Card>
  );
}
