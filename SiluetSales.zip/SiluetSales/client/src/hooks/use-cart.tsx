import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Product } from '@shared/schema';

interface CartItem {
  product: Product;
  quantity: number;
  size?: string;
  hasLipa: boolean;
  customization?: {
    view?: 'front' | 'back' | 'side';
    notes?: string;
    customerImage?: File;
  };
}

interface CartContextType {
  cart: CartItem[];
  addToCart: (
    product: Product,
    quantity: number,
    size?: string,
    hasLipa?: boolean,
    customization?: CartItem['customization']
  ) => void;
  removeFromCart: (item: CartItem) => void;
  updateQuantity: (item: CartItem, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>(() => {
    const savedCart = localStorage.getItem('cart');
    return savedCart ? JSON.parse(savedCart) : [];
  });

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (
    product: Product,
    quantity: number,
    size?: string,
    hasLipa = false,
    customization?: CartItem['customization']
  ) => {
    setCart(currentCart => {
      const existingItemIndex = currentCart.findIndex(
        item => 
          item.product.id === product.id && 
          item.size === size && 
          item.hasLipa === hasLipa &&
          JSON.stringify(item.customization) === JSON.stringify(customization)
      );

      if (existingItemIndex > -1) {
        const newCart = [...currentCart];
        newCart[existingItemIndex].quantity += quantity;
        return newCart;
      }

      return [...currentCart, { product, quantity, size, hasLipa, customization }];
    });
  };

  const removeFromCart = (item: CartItem) => {
    setCart(currentCart =>
      currentCart.filter(
        cartItem =>
          !(cartItem.product.id === item.product.id &&
            cartItem.size === item.size &&
            cartItem.hasLipa === item.hasLipa &&
            JSON.stringify(cartItem.customization) === JSON.stringify(item.customization))
      )
    );
  };

  const updateQuantity = (item: CartItem, quantity: number) => {
    if (quantity < 1) return;

    setCart(currentCart =>
      currentCart.map(cartItem =>
        cartItem.product.id === item.product.id &&
        cartItem.size === item.size &&
        cartItem.hasLipa === item.hasLipa &&
        JSON.stringify(cartItem.customization) === JSON.stringify(item.customization)
          ? { ...cartItem, quantity }
          : cartItem
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const totalItems = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalItems,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}