import { useQuery } from "@tanstack/react-query";
import { AboutPageContent } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { SiInstagram, SiFacebook, SiWhatsapp } from "react-icons/si";
import { BackToMenu } from "@/components/ui/back-to-menu";
import 'leaflet/dist/leaflet.css';

// Company location coordinates (example)
const COMPANY_LOCATION = {
  lat: 40.409264,
  lng: 49.867092
};

export default function AboutPage() {
  const { data: content, isLoading } = useQuery<AboutPageContent[]>({
    queryKey: ['/api/about'],
  });

  if (isLoading) {
    return (
      <div className="container py-6 space-y-6">
        <Skeleton className="h-8 w-[200px]" />
        <Skeleton className="h-[200px] w-full" />
        <Skeleton className="h-[100px] w-full" />
        <Skeleton className="h-[300px] w-full" />
      </div>
    );
  }

  const historyContent = content?.find(c => c.type === 'history');
  const missionContent = content?.find(c => c.type === 'mission');
  const contactContent = content?.find(c => c.type === 'contact');
  const locationContent = content?.find(c => c.type === 'location');

  return (
    <div className="container py-6 space-y-8">
      <BackToMenu />
      <h1 className="text-3xl font-bold">Haqqımızda</h1>

      {/* History Section */}
      <Card className="p-6">
        <h2 className="text-2xl font-semibold mb-4">
          {historyContent?.title || "Tariximiz"}
        </h2>
        <p className="text-muted-foreground">
          {historyContent?.content || 
           "SiluetBaku - Azərbaycanda siluet və poster hazırlanması xidməti."}
        </p>
      </Card>

      {/* Mission Section */}
      <Card className="p-6">
        <h2 className="text-2xl font-semibold mb-4">
          {missionContent?.title || "Missiyamız"}
        </h2>
        <p className="text-muted-foreground">
          {missionContent?.content ||
           "Yüksək keyfiyyətli siluetlər, posterlər və breloklar hazırlayaraq müştərilərimizə xüsusi xatirələr yaratmaq."}
        </p>
      </Card>

      {/* Social Media Links */}
      <Card className="p-6">
        <h2 className="text-2xl font-semibold mb-4">Sosial Media</h2>
        <div className="flex space-x-4">
          <a
            href="https://instagram.com/siluetbaku"
            target="_blank"
            rel="noopener noreferrer"
            className="text-4xl hover:text-primary transition-colors"
          >
            <SiInstagram />
          </a>
          <a
            href="https://facebook.com/siluetbaku"
            target="_blank"
            rel="noopener noreferrer"
            className="text-4xl hover:text-primary transition-colors"
          >
            <SiFacebook />
          </a>
          <a
            href="https://wa.me/994XXXXXXXXX"
            target="_blank"
            rel="noopener noreferrer"
            className="text-4xl hover:text-primary transition-colors"
          >
            <SiWhatsapp />
          </a>
        </div>
      </Card>

      {/* Contact & Location */}
      <Card className="p-6">
        <h2 className="text-2xl font-semibold mb-4">Əlaqə</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-xl font-medium mb-2">Bizə yazın</h3>
            <p className="text-muted-foreground mb-4">
              {contactContent?.content || "Suallarınız üçün bizimlə əlaqə saxlaya bilərsiniz."}
            </p>
            <p className="font-medium">Ünvan:</p>
            <p className="text-muted-foreground">
              {locationContent?.content || "Bakı şəhəri"}
            </p>
          </div>

          <div className="h-[300px] rounded-lg overflow-hidden">
            <MapContainer
              center={[COMPANY_LOCATION.lat, COMPANY_LOCATION.lng]}
              zoom={13}
              className="h-full w-full"
            >
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />
              <Marker position={[COMPANY_LOCATION.lat, COMPANY_LOCATION.lng]}>
                <Popup>
                  SiluetBaku
                </Popup>
              </Marker>
            </MapContainer>
          </div>
        </div>
      </Card>
    </div>
  );
}