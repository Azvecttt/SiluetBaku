import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Order, Product } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Building2, ArrowLeft, Plus, TrendingUp, Loader2, LogOut, Menu, X, Pencil, Trash2 } from "lucide-react";
import { Link, Redirect } from "wouter";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { z } from "zod";
import { Label } from "@/components/ui/label";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

const productSchema = z.object({
  name: z.string().min(1, "Ad tələb olunur"),
  type: z.string().min(1, "Növ tələb olunur"),
  basePrice: z.coerce.number().min(0, "Qiymət müsbət olmalıdır"),
  sizes: z.string().transform(s => s.split(',').map(size => size.trim()).filter(Boolean)),
  colors: z.array(z.object({
    name: z.string(),
    price: z.number(),
    isAvailable: z.boolean()
  })).default([{ name: 'Qara', price: 0, isAvailable: true }]),
  hasLipa: z.boolean().default(false),
  lipaPrice: z.coerce.number().min(0, "Lipa qiyməti müsbət olmalıdır").optional(),
  requiresImage: z.boolean().default(false),
  description: z.string().optional(),
  silhouettePositions: z.array(z.enum(['front', 'side', 'back'])).default(['front']),
  defaultColor: z.string().default('Qara'),
  isActive: z.boolean().default(true),
});

const domainSchema = z.object({
  metaTitle: z.string().optional(),
  metaDescription: z.string().optional(),
  metaKeywords: z.string().optional(),
  customDomain: z.string().optional()
});

export default function AdminPage() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const { data: orders = [], isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
    enabled: !!user?.isAdmin
  });

  const { data: products = [], isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    enabled: !!user?.isAdmin
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ orderId, status }: { orderId: number; status: string }) => {
      const res = await apiRequest("PATCH", `/api/orders/${orderId}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Sifariş statusu yeniləndi",
        description: "Müştəri dəyişiklik barədə məlumatlandırılacaq.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
    },
  });

  const productForm = useForm({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: "",
      type: "",
      basePrice: 0,
      sizes: "",
      colors: [{ name: 'Qara', price: 0, isAvailable: true }],
      hasLipa: false,
      lipaPrice: 0,
      requiresImage: false,
      description: "",
      silhouettePositions: ['front'],
      defaultColor: 'Qara',
      isActive: true,
    },
  });

  const addProductMutation = useMutation({
    mutationFn: async (data: z.infer<typeof productSchema>) => {
      const res = await apiRequest("POST", "/api/products", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Məhsul əlavə edildi",
        description: "Yeni məhsul uğurla əlavə edildi.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      productForm.reset();
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async (data: z.infer<typeof productSchema> & { id: number }) => {
      const { id, ...productData } = data;
      const res = await apiRequest("PATCH", `/api/products/${id}`, productData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Məhsul yeniləndi",
        description: "Məhsul məlumatları uğurla yeniləndi.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setEditingProduct(null);
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (productId: number) => {
      const res = await apiRequest("DELETE", `/api/products/${productId}`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Məhsul silindi",
        description: "Məhsul uğurla silindi.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
  });

  const handleEditProduct = (product: Product) => {
    productForm.reset({
      name: product.name,
      type: product.type,
      basePrice: product.basePrice,
      sizes: product.sizes?.join(','),
      colors: product.colors,
      hasLipa: product.hasLipa,
      lipaPrice: product.lipaPrice,
      requiresImage: product.requiresImage,
      description: product.description,
      silhouettePositions: product.silhouettePositions,
      defaultColor: product.defaultColor,
      isActive: product.isActive,
    });
    setEditingProduct(product);
  };

  const domainForm = useForm({
    resolver: zodResolver(domainSchema),
    defaultValues: {
      metaTitle: "",
      metaDescription: "",
      metaKeywords: "",
      customDomain: ""
    }
  });

  const updateDomainMutation = useMutation({
    mutationFn: async (data: z.infer<typeof domainSchema>) => {
      const res = await apiRequest("PATCH", "/api/settings/domain", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Domen tənzimləmələri yeniləndi",
        description: "Domen tənzimləmələri uğurla yeniləndi.",
      });
    },
  });

  const handleCustomize = (product: Product) => {
    setEditingProduct(product);
  };

  if (!user?.isAdmin) {
    return <Redirect to="/" />;
  }

  if (ordersLoading || productsLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white shadow">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Building2 className="w-6 h-6" />
                <h1 className="text-xl font-bold">SiluetBaku Admin</h1>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    <Skeleton className="h-6 w-32" />
                  </div>
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {Array.from({ length: 3 }).map((_, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <Skeleton className="h-5 w-24" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-8 w-16" />
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="mt-8 grid gap-8 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <Skeleton className="h-5 w-32" />
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px] flex items-center justify-center">
                      <Loader2 className="h-8 w-8 animate-spin text-primary/40" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <Skeleton className="h-5 w-40" />
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px] flex items-center justify-center">
                      <Loader2 className="h-8 w-8 animate-spin text-primary/40" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-24" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, index) => (
                  <Card key={index}>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start">
                        <div className="space-y-2">
                          <Skeleton className="h-5 w-32" />
                          <Skeleton className="h-4 w-24" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  const getProductName = (productId: number) => {
    return products.find((p) => p.id === productId)?.name || "Naməlum məhsul";
  };

  const getMonthlyOrders = () => {
    const monthlyData = new Array(12).fill(0);
    orders.forEach(order => {
      const month = new Date(order.createdAt).getMonth();
      monthlyData[month]++;
    });
    return monthlyData.map((count, index) => ({
      month: new Date(0, index).toLocaleString('az', { month: 'short' }),
      count
    }));
  };

  const getTopProducts = () => {
    const productCounts = orders.reduce((acc, order) => {
      acc[order.productId] = (acc[order.productId] || 0) + 1;
      return acc;
    }, {} as Record<number, number>);

    return Object.entries(productCounts)
      .map(([productId, count]) => ({
        name: getProductName(Number(productId)),
        value: count
      }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);
  };

  const getTotalRevenue = () => {
    return orders.reduce((total, order) => {
      const product = products.find(p => p.id === order.productId);
      if (!product) return total;
      let price = product.basePrice;
      if (order.hasLipa && product.lipaPrice) {
        price += product.lipaPrice;
      }
      return total + (price * order.quantity);
    }, 0);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="hover:bg-gray-100">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[300px] sm:w-[400px]">
                  <div className="flex flex-col gap-4 mt-8">
                    <h2 className="text-lg font-semibold">Admin Menyu</h2>
                    <nav className="flex flex-col gap-4">
                      <Link href="/admin">
                        <Button variant="ghost" className="w-full justify-start">
                          <Building2 className="w-4 h-4 mr-2" />
                          Admin Panel
                        </Button>
                      </Link>
                      <Link href="/">
                        <Button variant="ghost" className="w-full justify-start">
                          <ArrowLeft className="w-4 h-4 mr-2" />
                          Mağazaya qayıt
                        </Button>
                      </Link>
                      <Button
                        variant="destructive"
                        className="w-full justify-start bg-red-600 hover:bg-red-700"
                        onClick={() => {
                          logoutMutation.mutate(undefined, {
                            onSuccess: () => {
                              toast({
                                title: "Çıxış edildi",
                                description: "Hesabınızdan uğurla çıxış edildi",
                              });
                            }
                          });
                        }}
                        disabled={logoutMutation.isPending}
                      >
                        {logoutMutation.isPending ? (
                          <Loader2 className="w-4 h-4 animate-spin mr-2" />
                        ) : (
                          <LogOut className="w-4 h-4 mr-2" />
                        )}
                        Çıxış
                      </Button>
                    </nav>
                  </div>
                </SheetContent>
              </Sheet>
              <div className="flex items-center gap-2">
                <Building2 className="h-6 w-6" />
                <h1 className="text-xl font-bold">SiluetBaku Admin</h1>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-4">
              <Link href="/">
                <Button variant="outline">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Mağazaya qayıt
                </Button>
              </Link>
              <Button
                variant="destructive"
                className="bg-red-600 hover:bg-red-700"
                onClick={() => {
                  logoutMutation.mutate(undefined, {
                    onSuccess: () => {
                      toast({
                        title: "Çıxış edildi",
                        description: "Hesabınızdan uğurla çıxış edildi",
                      });
                    }
                  });
                }}
                disabled={logoutMutation.isPending}
              >
                {logoutMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <LogOut className="w-4 h-4 mr-2" />
                )}
                Çıxış
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Sifariş Analitikası
                </div>
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle>Ümumi Gəlir</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{getTotalRevenue()} AZN</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Ümumi Sifariş</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{orders.length}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Aktiv Məhsullar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{products.length}</div>
                </CardContent>
              </Card>
            </div>

            <div className="mt-8 grid gap-8 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Aylıq Sifarişlər</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={getMonthlyOrders()}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="count" fill="#3b82f6" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Ən Çox Satılan Məhsullar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={getTopProducts()}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          outerRadius={80}
                          label
                        >
                          {getTopProducts().map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={`hsl(${index * 45}, 70%, 50%)`} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Məhsullar</CardTitle>
            <Dialog>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Yeni məhsul
                </Button>
              </DialogTrigger>
              <DialogContent className="max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Yeni məhsul əlavə et</DialogTitle>
                </DialogHeader>
                <Form {...productForm}>
                  <form onSubmit={productForm.handleSubmit((data) => addProductMutation.mutate(data))} className="space-y-4">
                    <FormField
                      control={productForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Məhsulun adı</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={productForm.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Məhsul növü</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={productForm.control}
                      name="basePrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Baza qiyməti (AZN)</FormLabel>
                          <FormControl>
                            <Input type="number" min="0" step="0.01" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={productForm.control}
                      name="sizes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ölçülər (vergüllə ayırın)</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="S, M, L, XL" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="space-y-4">
                      <Label>Rənglər və qiymətləri</Label>
                      {productForm.watch('colors')?.map((_, index) => (
                        <div key={index} className="flex gap-2">
                          <FormField
                            control={productForm.control}
                            name={`colors.${index}.name`}
                            render={({ field }) => (
                              <FormItem className="flex-1">
                                <FormControl>
                                  <Input {...field} placeholder="Rəng adı" />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={productForm.control}
                            name={`colors.${index}.price`}
                            render={({ field }) => (
                              <FormItem className="flex-1">
                                <FormControl>
                                  <Input
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    {...field}
                                    placeholder="Əlavə qiymət"
                                    onChange={e => field.onChange(parseFloat(e.target.value))}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={productForm.control}
                            name={`colors.${index}.isAvailable`}
                            render={({ field }) => (
                              <FormItem>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <Button
                            type="button"
                            variant="destructive"
                            size="icon"
                            onClick={() => {
                              const colors = productForm.getValues('colors');
                              colors.splice(index, 1);
                              productForm.setValue('colors', colors);
                            }}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          const colors = productForm.getValues('colors') || [];
                          productForm.setValue('colors', [
                            ...colors,
                            { name: '', price: 0, isAvailable: true }
                          ]);
                        }}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Rəng əlavə et
                      </Button>
                    </div>

                    <FormField
                      control={productForm.control}
                      name="hasLipa"
                      render={({ field }) => (
                        <FormItem className="flex items-center gap-2">
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormLabel>Lipa dəstəyi</FormLabel>
                        </FormItem>
                      )}
                    />

                    {productForm.watch('hasLipa') && (
                      <FormField
                        control={productForm.control}
                        name="lipaPrice"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Lipa qiyməti (AZN)</FormLabel>
                            <FormControl>
                              <Input type="number" min="0" step="0.01" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}

                    <FormField
                      control={productForm.control}
                      name="requiresImage"
                      render={({ field }) => (
                        <FormItem className="flex items-center gap-2">
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormLabel>Şəkil tələb olunur</FormLabel>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={productForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Məhsul haqqında</FormLabel>
                          <FormControl>
                            <Textarea {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={productForm.control}
                      name="silhouettePositions"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Siluet mövqeləri</FormLabel>
                          <FormControl>
                            <div className="flex gap-2">
                              {['front', 'side', 'back'].map((position) => (
                                <Button
                                  key={position}
                                  type="button"
                                  variant={field.value.includes(position) ? "default" : "outline"}
                                  onClick={() => {
                                    const positions = field.value.includes(position)
                                      ? field.value.filter(p => p !== position)
                                      : [...field.value, position];
                                    field.onChange(positions);
                                  }}
                                >
                                  {position === 'front' ? 'Öndən' : position === 'side' ? 'Yandan' : 'Arxadan'}
                                </Button>
                              ))}
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button type="submit" className="w-full" disabled={addProductMutation.isPending}>
                      {addProductMutation.isPending ? (
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      ) : (
                        <Plus className="w-4 h-4 mr-2" />
                      )}
                      Məhsulu əlavə et
                    </Button>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px] pr-4">
              <div className="space-y-4">
                {products.map((product) => (
                  <Card key={product.id}>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold">{product.name}</h3>
                            {!product.isActive && (
                              <Badge variant="secondary">Deaktiv</Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{product.description}</p>
                          <div className="flex flex-wrap gap-2">
                            <Badge variant="outline">Baza: {product.basePrice} AZN</Badge>
                            {product.hasLipa && (
                              <Badge variant="outline">Lipa: +{product.lipaPrice} AZN</Badge>
                            )}
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {product.colors.map((color: any) => (
                              <Badge
                                key={color.name}
                                variant={color.isAvailable ? "default" : "secondary"}
                              >
                                {color.name} {color.price > 0 ? `+${color.price} AZN` : ''}
                              </Badge>
                            ))}
                          </div>
                          {product.sizes?.length > 0 && (
                            <div className="flex flex-wrap gap-2">
                              {product.sizes.map((size: string) => (
                                <Badge key={size} variant="outline">{size}</Badge>
                              ))}
                            </div>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() => {
                                  setEditingProduct(product);
                                  productForm.reset({
                                    name: product.name,
                                    type: product.type,
                                    basePrice: product.basePrice,
                                    sizes: product.sizes?.join(', ') || '',
                                    colors: product.colors || [{ name: 'Qara', price: 0, isAvailable: true }],
                                    hasLipa: product.hasLipa,
                                    lipaPrice: product.lipaPrice,
                                    requiresImage: product.requiresImage,
                                    description: product.description,
                                    silhouettePositions: product.silhouettePositions,
                                    defaultColor: product.defaultColor,
                                    isActive: product.isActive,
                                  });
                                }}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-h-[90vh] overflow-y-auto">
                              <DialogHeader>
                                <DialogTitle>Məhsulu redaktə et</DialogTitle>
                              </DialogHeader>
                              <Form {...productForm}>
                                <form
                                  onSubmit={productForm.handleSubmit((data) =>
                                    updateProductMutation.mutate({ ...data, id: editingProduct!.id })
                                  )}
                                  className="space-y-4"
                                >
                                  <FormField
                                    control={productForm.control}
                                    name="name"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Məhsulun adı</FormLabel>
                                        <FormControl>
                                          <Input {...field} />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  <FormField
                                    control={productForm.control}
                                    name="type"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Məhsul növü</FormLabel>
                                        <FormControl>
                                          <Input {...field} />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  <FormField
                                    control={productForm.control}
                                    name="basePrice"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Baza qiyməti (AZN)</FormLabel>
                                        <FormControl>
                                          <Input type="number" min="0" step="0.01" {...field} />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  <FormField
                                    control={productForm.control}
                                    name="sizes"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Ölçülər (vergüllə ayırın)</FormLabel>
                                        <FormControl>
                                          <Input {...field} placeholder="S, M, L, XL" />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />
                                  <div className="space-y-4">
                                    <Label>Rənglər və qiymətləri</Label>
                                    {productForm.watch('colors')?.map((_, index) => (
                                      <div key={index} className="flex gap-2">
                                        <FormField
                                          control={productForm.control}
                                          name={`colors.${index}.name`}
                                          render={({ field }) => (
                                            <FormItem className="flex-1">
                                              <FormControl>
                                                <Input {...field} placeholder="Rəng adı" />
                                              </FormControl>
                                            </FormItem>
                                          )}
                                        />
                                        <FormField
                                          control={productForm.control}
                                          name={`colors.${index}.price`}
                                          render={({ field }) => (
                                            <FormItem className="flex-1">
                                              <FormControl>
                                                <Input
                                                  type="number"
                                                  min="0"
                                                  step="0.01"
                                                  {...field}
                                                  placeholder="Əlavə qiymət"
                                                  onChange={e => field.onChange(parseFloat(e.target.value))}
                                                />
                                              </FormControl>
                                            </FormItem>
                                          )}
                                        />
                                        <FormField
                                          control={productForm.control}
                                          name={`colors.${index}.isAvailable`}
                                          render={({ field }) => (
                                            <FormItem>
                                              <FormControl>
                                                <Switch
                                                  checked={field.value}
                                                  onCheckedChange={field.onChange}
                                                />
                                              </FormControl>
                                            </FormItem>
                                          )}
                                        />
                                        <Button
                                          type="button"
                                          variant="destructive"
                                          size="icon"
                                          onClick={() => {
                                            const colors = productForm.getValues('colors');
                                            colors.splice(index, 1);
                                            productForm.setValue('colors', colors);
                                          }}
                                        >
                                          <X className="h-4 w-4" />
                                        </Button>
                                      </div>
                                    ))}
                                    <Button
                                      type="button"
                                      variant="outline"
                                      onClick={() => {
                                        const colors = productForm.getValues('colors') || [];
                                        productForm.setValue('colors', [
                                          ...colors,
                                          { name: '', price: 0, isAvailable: true }
                                        ]);
                                      }}
                                    >
                                      <Plus className="h-4 w-4 mr-2" />
                                      Rəng əlavə et
                                    </Button>
                                  </div>

                                  <FormField
                                    control={productForm.control}
                                    name="hasLipa"
                                    render={({ field }) => (
                                      <FormItem className="flex items-center gap-2">
                                        <FormControl>
                                          <Switch
                                            checked={field.value}
                                            onCheckedChange={field.onChange}
                                          />
                                        </FormControl>
                                        <FormLabel>Lipa dəstəyi</FormLabel>
                                      </FormItem>
                                    )}
                                  />

                                  {productForm.watch('hasLipa') && (
                                    <FormField
                                      control={productForm.control}
                                      name="lipaPrice"
                                      render={({ field }) => (
                                        <FormItem>
                                          <FormLabel>Lipa qiyməti (AZN)</FormLabel>
                                          <FormControl>
                                            <Input type="number" min="0" step="0.01" {...field} />
                                          </FormControl>
                                          <FormMessage />
                                        </FormItem>
                                      )}
                                    />
                                  )}

                                  <FormField
                                    control={productForm.control}
                                    name="requiresImage"
                                    render={({ field }) => (
                                      <FormItem className="flex items-center gap-2">
                                        <FormControl>
                                          <Switch
                                            checked={field.value}
                                            onCheckedChange={field.onChange}
                                          />
                                        </FormControl>
                                        <FormLabel>Şəkil tələb olunur</FormLabel>
                                      </FormItem>
                                    )}
                                  />

                                  <FormField
                                    control={productForm.control}
                                    name="description"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Məhsul haqqında</FormLabel>
                                        <FormControl>
                                          <Textarea {...field} />
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />

                                  <FormField
                                    control={productForm.control}
                                    name="silhouettePositions"
                                    render={({ field }) => (
                                      <FormItem>
                                        <FormLabel>Siluet mövqeləri</FormLabel>
                                        <FormControl>
                                          <div className="flex gap-2">
                                            {['front', 'side', 'back'].map((position) => (
                                              <Button
                                                key={position}
                                                type="button"
                                                variant={field.value.includes(position) ? "default" : "outline"}
                                                onClick={() => {
                                                  const positions = field.value.includes(position)
                                                    ? field.value.filter(p => p !== position)
                                                    : [...field.value, position];
                                                  field.onChange(positions);
                                                }}
                                              >
                                                {position === 'front' ? 'Öndən' : position === 'side' ? 'Yandan' : 'Arxadan'}
                                              </Button>
                                            ))}
                                          </div>
                                        </FormControl>
                                        <FormMessage />
                                      </FormItem>
                                    )}
                                  />

                                  <Button type="submit" className="w-full" disabled={updateProductMutation.isPending}>
                                    {updateProductMutation.isPending ? (
                                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                                    ) : (
                                      <Pencil className="w-4 h-4 mr-2" />
                                    )}
                                    Məhsulu yenilə
                                  </Button>
                                </form>
                              </Form>
                            </DialogContent>
                          </Dialog>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="outline" size="icon" className="text-red-600">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Məhsulu silmək istədiyinizdən əminsiniz?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Bu əməliyyat geri qaytarıla bilməz. Məhsul birdəfəlik silinəcək.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Ləğv et</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => deleteProductMutation.mutate(product.id)}
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  {deleteProductMutation.isPending ? (
                                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                                  ) : (
                                    <Trash2 className="w-4 h-4 mr-2" />
                                  )}
                                  Sil
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Sifarişlər</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px] pr-4">
              <div className="space-y-4">
                {orders.map((order) => (
                  <Card key={order.id}>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-bold">Sifariş #{order.id}</h3>
                          <p className="text-sm text-gray-600">{getProductName(order.productId)}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Domen Tənzimləmələri</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...domainForm}>
              <form onSubmit={domainForm.handleSubmit((data) => updateDomainMutation.mutate(data))} className="space-y-4">
                <FormField
                  control={domainForm.control}
                  name="customDomain"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Xüsusi domen</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="siluetbaku.replit.app" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={updateDomainMutation.isPending}>
                  {updateDomainMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  ) : null}
                  Tənzimləmələri yenilə
                </Button>
              </form>
            </Form>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold">Cari domen</h3>
                  <p className="text-sm text-gray-600">siluetbaku.repl.co</p>
                </div>
                <Badge variant="outline">Aktiv</Badge>
              </div>

              <div className="space-y-4">
                <h3 className="font-semibold">SEO Meta taqları</h3>
                <Form {...domainForm}>
                  <form className="space-y-4">
                    <FormField
                      control={domainForm.control}
                      name="metaTitle"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Səhifə başlığı</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="SiluetBaku - Siluet və Poster Hazırlanması" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={domainForm.control}
                      name="metaDescription"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Səhifə təsviri</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Azərbaycanda siluet və poster hazırlanması xidməti..." />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button type="submit" className="w-full">
                      Meta taqları yenilə
                    </Button>
                  </form>
                </Form>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

    </div>
  );
}