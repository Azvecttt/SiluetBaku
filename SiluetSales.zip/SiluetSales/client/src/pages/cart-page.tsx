import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { useCart } from "@/hooks/use-cart";
import { Minus, Plus, Trash2, ArrowLeft } from "lucide-react";
import { PaymentForm } from "@/components/ui/payment-form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertOrderSchema } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Link } from "wouter";
import { BackToMenu } from "@/components/ui/back-to-menu";

export default function CartPage() {
  const { user } = useAuth();
  const { cart, updateQuantity, removeFromCart, clearCart } = useCart();
  const { toast } = useToast();

  const orderForm = useForm({
    resolver: zodResolver(insertOrderSchema),
    defaultValues: {
      address: "",
      phoneNumber: user?.phoneNumber || "",
    },
  });

  const orderMutation = useMutation({
    mutationFn: async (data: any) => {
      const orders = await Promise.all(
        cart.map(async (item) => {
          const orderData = {
            productId: item.product.id,
            quantity: item.quantity,
            hasLipa: item.hasLipa,
            address: data.address,
            phoneNumber: data.phoneNumber,
            size: item.size,
          };
          const res = await apiRequest("POST", "/api/orders", orderData);
          return res.json();
        })
      );
      return orders;
    },
    onSuccess: () => {
      toast({
        title: "Sifariş uğurla yerləşdirildi!",
        description: "Sifariş statusu haqqında məlumatlar sizə göndəriləcək.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      clearCart();
      orderForm.reset();
    },
  });

  const calculateTotal = () => {
    return cart.reduce((total, item) => {
      let itemTotal = item.product.basePrice * item.quantity;
      if (item.hasLipa && item.product.hasLipa && item.product.lipaPrice) {
        itemTotal += item.product.lipaPrice;
      }
      return total + itemTotal;
    }, 0);
  };

  const handlePaymentSuccess = () => {
    orderMutation.mutate(orderForm.getValues());
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <BackToMenu />
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold">Səbətiniz boşdur</h1>
          <p className="text-muted-foreground">
            Məhsulları səbətə əlavə etmək üçün mağazaya qayıdın
          </p>
          <Link href="/">
            <Button className="mt-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Mağazaya qayıt
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <BackToMenu />
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Səbət</h1>
        <Link href="/">
          <Button variant="outline">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Mağazaya qayıt
          </Button>
        </Link>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-4">
          {cart.map((item) => (
            <Card key={`${item.product.id}-${item.size}`}>
              <CardContent className="p-4">
                <div className="flex gap-4">
                  {item.product.image && (
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-24 h-24 object-cover rounded"
                    />
                  )}
                  <div className="flex-1">
                    <h3 className="font-semibold">{item.product.name}</h3>
                    {item.size && (
                      <p className="text-sm text-muted-foreground">
                        Ölçü: {item.size}
                      </p>
                    )}
                    {item.hasLipa && (
                      <p className="text-sm text-muted-foreground">
                        +Lipa ({item.product.lipaPrice}₼)
                      </p>
                    )}
                    <div className="flex items-center gap-2 mt-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => updateQuantity(item, item.quantity - 1)}
                        disabled={item.quantity <= 1}
                      >
                        <Minus className="w-4 h-4" />
                      </Button>
                      <span>{item.quantity}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => updateQuantity(item, item.quantity + 1)}
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="icon"
                        className="ml-auto"
                        onClick={() => removeFromCart(item)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Sifariş məlumatları</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...orderForm}>
                <form className="space-y-4">
                  <FormField
                    control={orderForm.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Çatdırılma ünvanı</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={orderForm.control}
                    name="phoneNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Telefon nömrəsi</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </form>
              </Form>
            </CardContent>
            <CardFooter className="flex-col space-y-4">
              <div className="w-full flex justify-between text-lg font-bold">
                <span>Cəmi:</span>
                <span>{calculateTotal()}₼</span>
              </div>
              <PaymentForm
                amount={calculateTotal()}
                onSuccess={handlePaymentSuccess}
              />
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}