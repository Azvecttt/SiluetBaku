import { useQuery } from "@tanstack/react-query";
import { Product, CustomerShowcase } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { BackToMenu } from "@/components/ui/back-to-menu";

export default function DiscoverPage() {
  const { toast } = useToast();

  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  const { data: showcases, isLoading: showcasesLoading } = useQuery<CustomerShowcase[]>({
    queryKey: ['/api/customer-showcases'],
  });

  if (productsLoading || showcasesLoading) {
    return <div className="container grid gap-4 py-6 md:grid-cols-2 lg:grid-cols-3">
      {Array(6).fill(0).map((_, i) => (
        <Card key={i} className="p-4">
          <Skeleton className="h-[200px] w-full rounded-lg" />
          <Skeleton className="mt-4 h-4 w-[250px]" />
          <Skeleton className="mt-2 h-4 w-[200px]" />
        </Card>
      ))}
    </div>;
  }

  return (
    <div className="container py-6">
      <BackToMenu />
      <Tabs defaultValue="products" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="products">Bütün Məhsullar</TabsTrigger>
          <TabsTrigger value="showcases">Müştəri Nümunələri</TabsTrigger>
        </TabsList>
        <TabsContent value="products" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {products?.map((product) => (
              <Card key={product.id} className="overflow-hidden">
                <AspectRatio ratio={4/3}>
                  <img 
                    src={product.images[0]} 
                    alt={product.name}
                    className="object-cover w-full h-full"
                  />
                </AspectRatio>
                <div className="p-4">
                  <h3 className="text-lg font-semibold">{product.name}</h3>
                  <p className="text-sm text-muted-foreground">{product.type}</p>
                  <p className="mt-2 font-medium">
                    {product.basePrice} AZN-dən başlayaraq
                  </p>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="showcases" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {showcases?.map((showcase) => (
              <Card key={showcase.id} className="overflow-hidden">
                <AspectRatio ratio={4/3}>
                  <img 
                    src={showcase.image} 
                    alt={showcase.customerName || 'Müştəri nümunəsi'}
                    className="object-cover w-full h-full"
                  />
                </AspectRatio>
                <div className="p-4">
                  {showcase.customerName && (
                    <h3 className="text-lg font-semibold">{showcase.customerName}</h3>
                  )}
                  {showcase.description && (
                    <p className="text-sm text-muted-foreground">{showcase.description}</p>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}