import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { Link } from "wouter";
import { Menu, ShoppingCart, ShoppingBag, LogOut, User } from "lucide-react";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { useState, useEffect } from 'react';
import { useCart } from "@/hooks/use-cart";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { SupportChat } from "@/components/ui/support-chat";
import { Loader2 } from "lucide-react";
import { ProductCardSkeleton } from "@/components/ui/skeleton";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const { addToCart, cart } = useCart();
  const { toast } = useToast();
  const { data: products = [], isLoading: productsLoading } = useQuery<Product[]>({ queryKey: ["/api/products"] });
  const [totalItems, setTotalItems] = useState(0);

  useEffect(() => {
    setTotalItems(cart.reduce((sum, item) => sum + item.quantity, 0));
  }, [cart]);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-sm border-b border-white/10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="lg:hidden">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[300px] sm:w-[400px] bg-black/95">
                  <nav className="flex flex-col gap-4">
                    <Link href="/profile" className="flex items-center gap-2 p-2 hover:bg-white/10 rounded-lg transition-colors">
                      <User className="w-4 h-4" />
                      <span>Profil</span>
                    </Link>
                    {user?.isAdmin && (
                      <Link href="/admin" className="flex items-center gap-2 p-2 hover:bg-white/10 rounded-lg transition-colors">
                        <span>Admin Panel</span>
                      </Link>
                    )}
                    <Button
                      variant="destructive"
                      className="mt-2"
                      onClick={() => {
                        logoutMutation.mutate(undefined, {
                          onSuccess: () => {
                            toast({
                              title: "Çıxış edildi",
                              description: "Hesabınızdan uğurla çıxış edildi",
                            });
                          }
                        });
                      }}
                      disabled={logoutMutation.isPending}
                    >
                      {logoutMutation.isPending ? (
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      ) : (
                        <LogOut className="w-4 h-4 mr-2" />
                      )}
                      Çıxış
                    </Button>
                  </nav>
                </SheetContent>
              </Sheet>
              <Link href="/">
                <img
                  src="/assets/IMG_1878.jpeg"
                  alt="SiluetBaku"
                  className="h-10 w-auto object-contain hover:opacity-80 transition-opacity"
                />
              </Link>
            </div>

            <div className="flex items-center gap-2 sm:gap-4">
              <nav className="hidden lg:flex items-center gap-4">
                <Link href="/profile">
                  <Button variant="ghost" className="text-white hover:bg-white/10">
                    <User className="w-4 h-4 mr-2" />
                    Profil
                  </Button>
                </Link>
                {user?.isAdmin && (
                  <Link href="/admin">
                    <Button variant="ghost" className="text-white hover:bg-white/10">
                      Admin Panel
                    </Button>
                  </Link>
                )}
                <Button
                  variant="destructive"
                  onClick={() => {
                    logoutMutation.mutate(undefined, {
                      onSuccess: () => {
                        toast({
                          title: "Çıxış edildi",
                          description: "Hesabınızdan uğurla çıxış edildi",
                        });
                      }
                    });
                  }}
                  disabled={logoutMutation.isPending}
                  className="bg-red-600 hover:bg-red-700"
                >
                  {logoutMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  ) : (
                    <LogOut className="w-4 h-4 mr-2" />
                  )}
                  Çıxış
                </Button>
              </nav>
              <ThemeToggle />
              <Link href="/cart" className="relative">
                <Button variant="outline" size="icon" className="border-white/20 hover:bg-white/10">
                  <ShoppingCart className="h-5 w-5" />
                  {totalItems > 0 && (
                    <span className="absolute -top-2 -right-2 bg-primary text-white rounded-full w-5 h-5 text-xs flex items-center justify-center">
                      {totalItems}
                    </span>
                  )}
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden pt-16">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-primary/20 to-black/95 mix-blend-overlay"></div>
          <img
            src="/assets/IMG_1878.jpeg"
            alt="Hero Background"
            className="w-full h-full object-cover object-center opacity-50"
          />
        </div>
        <div className="container relative z-10 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-4xl sm:text-6xl lg:text-7xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-primary/60 mb-6"
          >
            SiluetBaku
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl sm:text-2xl text-white/80 mb-8 max-w-2xl mx-auto"
          >
            Yüksək keyfiyyətli məhsullar ilə sizin xidmətinizdəyik
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Link href="/discover">
              <Button size="lg" className="bg-primary hover:bg-primary/80 text-white">
                Məhsullarımızı Kəşf Edin
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-16 space-y-16">
        {/* Featured Products */}
        <section>
          <h2 className="text-3xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-white to-primary/60">
            Seçilmiş Məhsullar
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {productsLoading ? (
              Array.from({ length: 6 }).map((_, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="group bg-black/50 border border-white/10">
                    <CardContent className="pt-6">
                      <ProductCardSkeleton />
                    </CardContent>
                  </Card>
                </motion.div>
              ))
            ) : (
              products?.map((product) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="group bg-black/50 border border-white/10 hover:border-primary/50 transition-all duration-300">
                    <CardHeader>
                      {product.images && product.images.length > 0 && (
                        <div className="relative overflow-hidden rounded-lg">
                          <img
                            src={product.images[0]}
                            alt={product.name}
                            className="w-full h-64 object-cover transform group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                        </div>
                      )}
                      <CardTitle className="text-xl mt-4 group-hover:text-primary transition-colors">
                        {product.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-white/60">{product.description}</p>
                      <p className="text-2xl font-bold mt-4 text-primary">
                        {product.basePrice} AZN
                      </p>
                      {product.hasLipa && (
                        <p className="text-sm text-white/40">
                          +{product.lipaPrice} AZN lipa üçün
                        </p>
                      )}
                    </CardContent>
                    <CardFooter className="pt-4">
                      <Button
                        className="w-full bg-white/10 hover:bg-primary text-white border border-white/20 hover:border-primary group"
                        onClick={() => {
                          addToCart(product, 1);
                          toast({
                            title: "Məhsul səbətə əlavə edildi",
                            description: "Sifarişi tamamlamaq üçün səbətə keçin",
                          });
                        }}
                      >
                        <ShoppingBag className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
                        Səbətə əlavə et
                      </Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))
            )}
          </div>
        </section>
      </main>

      {/* Support Chat */}
      <SupportChat />
    </div>
  );
}