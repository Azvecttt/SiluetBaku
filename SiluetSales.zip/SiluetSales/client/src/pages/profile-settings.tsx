import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { User, LogOut, Loader2 } from "lucide-react";
import { ProfileSkeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";
import { BackToMenu } from "@/components/ui/back-to-menu";

const profileSettingsSchema = z.object({
  name: z.string().min(2, "Ad ən az 2 simvol olmalıdır"),
  phoneNumber: z.string().min(10, "Telefon nömrəsi ən az 10 rəqəm olmalıdır").optional(),
  email: z.string().email("Düzgün e-poçt ünvanı daxil edin").optional(),
  birthDate: z.string().optional(),
});

type ProfileFormData = z.infer<typeof profileSettingsSchema>;

export default function ProfileSettingsPage() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();

  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ["/api/user/profile"],
    enabled: !!user
  });

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSettingsSchema),
    defaultValues: {
      name: profile?.name || user?.name || "",
      phoneNumber: profile?.phoneNumber || user?.phoneNumber || "",
      email: profile?.email || user?.email || "",
      birthDate: profile?.birthDate || user?.birthDate || "",
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      const res = await apiRequest("PATCH", "/api/user/profile", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Profil yeniləndi",
        description: "Məlumatlarınız uğurla yeniləndi",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Xəta",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ProfileFormData) => {
    updateProfileMutation.mutate(data);
  };

  if (profileLoading) {
    return (
      <div className="min-h-screen bg-black text-white">
        <div className="max-w-4xl mx-auto px-4 py-8 md:py-12">
          <BackToMenu />
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center gap-4 mb-8"
          >
            <div className="bg-primary/10 p-3 rounded-full">
              <User className="w-6 h-6 text-primary" />
            </div>
            <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-white to-primary/60 bg-clip-text text-transparent">
              Profil Ayarları
            </h1>
          </motion.div>
          <ProfileSkeleton />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="max-w-4xl mx-auto px-4 py-8 md:py-12">
        <BackToMenu />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center gap-4 mb-8"
        >
          <div className="bg-primary/10 p-3 rounded-full">
            <User className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-white to-primary/60 bg-clip-text text-transparent">
            Profil Ayarları
          </h1>
        </motion.div>

        <div className="grid gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <Card className="bg-black/50 border border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Şəxsi Məlumatlar</CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Ad Soyad</FormLabel>
                          <FormControl>
                            <Input {...field} className="bg-white/5 border-white/10 text-white" placeholder="Ad Soyad" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid gap-6 md:grid-cols-2">
                      <FormField
                        control={form.control}
                        name="phoneNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Telefon nömrəsi</FormLabel>
                            <FormControl>
                              <Input {...field} className="bg-white/5 border-white/10 text-white" placeholder="+994 XX XXX XX XX" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">E-poçt ünvanı</FormLabel>
                            <FormControl>
                              <Input {...field} type="email" className="bg-white/5 border-white/10 text-white" placeholder="sizin@email.com" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="birthDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Doğum tarixi</FormLabel>
                          <FormControl>
                            <Input {...field} type="date" className="w-full md:w-auto bg-white/5 border-white/10 text-white" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button
                      type="submit"
                      className="w-full md:w-auto bg-primary hover:bg-primary/80 text-white group relative"
                      disabled={updateProfileMutation.isPending}
                    >
                      <span className="flex items-center justify-center">
                        {updateProfileMutation.isPending ? (
                          <>
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                            Yenilənir...
                          </>
                        ) : (
                          <>
                            <User className="h-4 w-4 mr-2 group-hover:scale-110 transition-transform" />
                            Məlumatları Yenilə
                          </>
                        )}
                      </span>
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card className="bg-black/50 border border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Bildiriş Ayarları</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex items-center justify-between p-4 rounded-lg border border-white/10 bg-white/5">
                    <Label htmlFor="push-notifications" className="font-medium text-white">Push Bildirişlər</Label>
                    <Switch id="push-notifications" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg border border-white/10 bg-white/5">
                    <Label htmlFor="sms-notifications" className="font-medium text-white">SMS Bildirişlər</Label>
                    <Switch id="sms-notifications" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg border border-white/10 bg-white/5">
                    <Label htmlFor="email-notifications" className="font-medium text-white">E-poçt Bildirişləri</Label>
                    <Switch id="email-notifications" defaultChecked />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Card className="bg-black/50 border border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Hesab Ayarları</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex flex-col space-y-2">
                    <Label className="text-white">Hesabdan Çıxış</Label>
                    <p className="text-sm text-white/60">
                      Hesabınızdan çıxış edəcəksiniz. Yenidən daxil olmaq üçün giriş məlumatlarınızı istifadə edin.
                    </p>
                  </div>
                  <Button
                    variant="destructive"
                    className="w-full md:w-auto"
                    onClick={() => {
                      logoutMutation.mutate(undefined, {
                        onSuccess: () => {
                          toast({
                            title: "Çıxış edildi",
                            description: "Hesabınızdan uğurla çıxış edildi",
                          });
                        }
                      });
                    }}
                    disabled={logoutMutation.isPending}
                  >
                    <span className="flex items-center justify-center">
                      {logoutMutation.isPending ? (
                        <>
                          <Loader2 className="h-4 h-4 animate-spin mr-2" />
                          Çıxış edilir...
                        </>
                      ) : (
                        <>
                          <LogOut className="h-4 w-4 mr-2" />
                          Hesabdan Çıxış
                        </>
                      )}
                    </span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}