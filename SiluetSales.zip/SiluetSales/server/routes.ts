import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { log } from "./vite";
import {
  insertOrderSchema,
  insertProductSchema,
  insertNotificationSchema,
  insertSocialMediaPostSchema,
  insertEmojiReactionSchema,
  supportMessages,
  insertSupportMessageSchema,
  users,
  insertCustomerShowcaseSchema,
  insertWelcomeWheelRewardSchema,
  insertAboutPageContentSchema,
  customerShowcase,
  welcomeWheelRewards,
  aboutPageContent,
} from "@shared/schema";
import { createPaymentIntent, createApplePayPayment } from "./services/payments";
import { sendMultiChannelNotification } from "./services/notifications";
import webpush from 'web-push';
import { recommendationService } from "./services/recommendation-service";
import {hashPassword} from './auth';
import { sendOrderNotification, sendSupportMessage } from './services/telegram-bot';

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  // Support chat routes
  app.get("/api/support/messages", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      log("Fetching support messages for user:", req.user!.id);
      const messages = await db.select().from(supportMessages)
        .where(eq(supportMessages.userId, req.user!.id))
        .orderBy(supportMessages.createdAt);

      log("Found messages:", messages.length);
      res.json(messages);
    } catch (error) {
      console.error('Error fetching support messages:', error);
      res.status(500).json({ message: "Failed to fetch support messages" });
    }
  });

  app.post("/api/support/messages", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    try {
      const parseResult = insertSupportMessageSchema.safeParse({
        userId: req.user!.id,
        content: req.body.content,
        isAdmin: false,
      });
      if (!parseResult.success) {
        return res.status(400).json(parseResult.error);
      }
      const [message] = await db.insert(supportMessages)
        .values(parseResult.data)
        .returning();
      // Send message to Telegram
      await sendSupportMessage(req.user!.id, req.body.content);
      res.json(message);
    } catch (error) {
      console.error('Error creating support message:', error);
      res.status(500).json({ message: "Failed to create support message" });
    }
  });

  app.patch("/api/user/profile", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    try {
      const [updatedUser] = await db
        .update(users)
        .set({
          phoneNumber: req.body.phoneNumber || null,
          email: req.body.email || null,
          birthDate: req.body.birthDate || null,
        })
        .where(eq(users.id, req.user!.id))
        .returning();
      res.json(updatedUser);
    } catch (error) {
      console.error('Error updating user profile:', error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.post("/api/social-login", async (req, res) => {
    const { provider, token } = req.body;
    try {
      let profile;
      if (provider === 'google') {
        // Verify Google token and get profile
        const response = await fetch(`https://www.googleapis.com/oauth2/v3/userinfo`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (!response.ok) {
          throw new Error('Google token doğrulanması uğursuz oldu');
        }
        profile = await response.json();
      } else {
        return res.status(400).json({ message: 'Yalnız Google ilə giriş aktiv edilib' });
      }
      // Check if user exists
      let user = await storage.getUserByUsername(profile.email);
      if (!user) {
        // Create new user
        user = await storage.createUser({
          username: profile.email,
          password: await hashPassword(Math.random().toString(36)), // Random password for social users
          email: profile.email,
          phoneNumber: null,
          birthDate: null,
          isAdmin: false,
          points: 0,
          onboardingCompleted: false,
        });
      }
      // Login user
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: 'Giriş uğursuz oldu' });
        }
        res.json(user);
      });
    } catch (error) {
      console.error('Social login error:', error);
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/products", async (_req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });

  app.post("/api/products", async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) {
      return res.sendStatus(401);
    }
    const parseResult = insertProductSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json(parseResult.error);
    }
    const product = await storage.createProduct(parseResult.data);
    res.status(201).json(product);
  });

  app.patch("/api/products/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) {
      return res.sendStatus(401);
    }
    const productId = parseInt(req.params.id);
    const parseResult = insertProductSchema.partial().safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json(parseResult.error);
    }
    const product = await storage.updateProduct(productId, parseResult.data);
    res.json(product);
  });

  app.delete("/api/products/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) {
      return res.sendStatus(401);
    }
    const productId = parseInt(req.params.id);
    await storage.deleteProduct(productId);
    res.sendStatus(204);
  });

  app.get("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const userId = req.user!.isAdmin ? undefined : req.user!.id;
    const orders = await storage.getOrders(userId);
    res.json(orders);
  });

  app.post("/api/orders", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const parseResult = insertOrderSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json(parseResult.error);
    }

    try {
      // Get product to calculate total price
      const product = await storage.getProducts().then(products =>
        products.find(p => p.id === parseResult.data.productId)
      );

      if (!product) {
        return res.status(400).json({ message: "Məhsul tapılmadı" });
      }

      // Calculate total price
      let totalPrice = product.basePrice * parseResult.data.quantity;

      // Add lipa price if selected
      if (parseResult.data.hasLipa && product.hasLipa && product.lipaPrice) {
        totalPrice += product.lipaPrice;
      }

      // Add color price if applicable
      const selectedColor = product.colors.find(c => c.name === parseResult.data.color);
      if (selectedColor) {
        totalPrice += selectedColor.price * parseResult.data.quantity;
      }

      // Apply welcome reward if provided
      if (parseResult.data.welcomeRewardId) {
        const reward = await db.select()
          .from(welcomeWheelRewards)
          .where(eq(welcomeWheelRewards.id, parseResult.data.welcomeRewardId))
          .limit(1);

        if (reward.length > 0 && !reward[0].isUsed && reward[0].expiresAt > new Date()) {
          switch (reward[0].rewardType) {
            case 'discount':
              if (reward[0].discountPercentage) {
                totalPrice = totalPrice * (1 - reward[0].discountPercentage / 100);
              }
              break;
            case 'free_shipping':
              // Assume 5 AZN shipping cost
              totalPrice = Math.max(0, totalPrice - 5);
              break;
            case 'free_gift_wrap':
              // Assume 3 AZN gift wrap cost
              totalPrice = Math.max(0, totalPrice - 3);
              break;
            case 'free_lipa':
              if (parseResult.data.hasLipa && product.hasLipa && product.lipaPrice) {
                totalPrice = Math.max(0, totalPrice - product.lipaPrice);
              }
              break;
          }
          // Mark reward as used
          await db.update(welcomeWheelRewards)
            .set({ isUsed: true })
            .where(eq(welcomeWheelRewards.id, parseResult.data.welcomeRewardId));
        }
      }

      // Apply referral discount if code provided
      if (parseResult.data.referralCode) {
        const referrer = await storage.getUserByReferralCode(parseResult.data.referralCode);
        if (referrer && referrer.id !== req.user!.id) {
          // Apply 10 AZN discount for both users
          totalPrice = Math.max(0, totalPrice - 10);
          await storage.addReferralReward(referrer.id, req.user!.id);
        }
      }

      const order = await storage.createOrder({
        ...parseResult.data,
        userId: req.user!.id,
        totalPrice: Math.round(totalPrice), // Round to avoid floating point issues
      });

      // Send notification to Telegram
      await sendOrderNotification(
        order.id,
        "Yeni",
        `Məhsul: ${product.name}\nMiqdar: ${parseResult.data.quantity}\nÜmumi qiymət: ${totalPrice} AZN`
      );

      res.status(201).json(order);
    } catch (error) {
      console.error('Error creating order:', error);
      res.status(500).json({ message: "Sifariş yaradılmadı" });
    }
  });

  app.patch("/api/orders/:id/status", async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) {
      return res.sendStatus(401);
    }
    const orderId = parseInt(req.params.id);
    const { status, location } = req.body;
    if (!status || typeof status !== "string") {
      return res.status(400).json({ message: "Invalid status" });
    }
    const order = await storage.updateOrderStatus(orderId, status);
    // Add status history
    await storage.addOrderStatusHistory({
      orderId,
      status,
      location: location || null,
      notes: req.body.notes,
    });
    // Send multi-channel notification
    await sendMultiChannelNotification(
      `Sifarişinizin (${orderId}) statusu yeniləndi: ${status}`,
      order.userId
    );
    res.json(order);
  });
  app.get("/api/onboarding/steps", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const steps = await storage.getOnboardingSteps();
    res.json(steps);
  });

  app.get("/api/onboarding/progress", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const progress = await storage.getUserProgress(req.user!.id);
    res.json(progress);
  });

  app.post("/api/onboarding/progress/:stepId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const stepId = parseInt(req.params.stepId);
    await storage.completeOnboardingStep(req.user!.id, stepId);
    res.sendStatus(200);
  });
  app.get("/api/rewards", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const rewards = await storage.getRewards();
    res.json(rewards);
  });

  app.get("/api/rewards/user", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const userRewards = await storage.getUserRewards(req.user!.id);
    res.json(userRewards);
  });

  app.post("/api/rewards/:rewardId/claim", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const rewardId = parseInt(req.params.rewardId);
    await storage.claimReward(req.user!.id, rewardId);
    res.sendStatus(200);
  });
  app.post("/api/payments/create-payment-intent", async (req, res) => {
    try {
      const { amount } = req.body;
      const clientSecret = await createPaymentIntent(amount);
      res.json({ clientSecret });
    } catch (error) {
      res.status(500).json({ error: "Payment failed" });
    }
  });

  app.post("/api/payments/apple-pay", async (req, res) => {
    try {
      const { amount, paymentMethodId } = req.body;
      if (!paymentMethodId) {
        return res.status(400).json({ error: "Payment method ID is required" });
      }
      const clientSecret = await createApplePayPayment(amount, paymentMethodId);
      res.json({ clientSecret });
    } catch (error) {
      console.error('Apple Pay payment error:', error);
      res.status(500).json({ error: "Apple Pay payment failed" });
    }
  });
  app.post("/api/notifications/subscribe", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const subscription = req.body;
    await storage.savePushSubscription({
      userId: req.user!.id,
      endpoint: subscription.endpoint,
      p256dh: subscription.keys.p256dh,
      auth: subscription.keys.auth,
    });
    res.json({ publicKey: process.env.VAPID_PUBLIC_KEY });
  });

  app.get("/api/notifications", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const notifications = await storage.getUserNotifications(req.user!.id);
    res.json(notifications);
  });
  app.get("/api/orders/:orderId/history", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const orderId = parseInt(req.params.orderId);
    const history = await storage.getOrderStatusHistory(orderId);
    res.json(history);
  });

  app.post("/api/orders/:orderId/location", async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) {
      return res.sendStatus(401);
    }
    const orderId = parseInt(req.params.orderId);
    const { location } = req.body;
    await storage.updateOrderLocation(orderId, location);
    res.sendStatus(200);
  });
  app.post("/api/referrals/generate", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const existingCode = await storage.getUserReferralCode(req.user!.id);
    if (existingCode) {
      return res.json({ code: existingCode });
    }
    const code = await storage.generateReferralCode(req.user!.id);
    res.json({ code });
  });

  app.get("/api/referrals/rewards", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const rewards = await storage.getReferralRewards(req.user!.id);
    res.json(rewards);
  });
  app.get("/api/offers", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    // Get regular offers
    const regularOffers = await storage.getUserSpecialOffers(req.user!.id);
    // Check for birthday offers if user has birthDate
    let birthdayOffers = [];
    if (req.user!.birthDate) {
      const today = new Date();
      const birthDate = new Date(req.user!.birthDate);
      if (today.getMonth() === birthDate.getMonth() &&
        today.getDate() === birthDate.getDate()) {
        birthdayOffers = [{
          id: 'birthday',
          name: 'Doğum Günü Xüsusi Təklifi',
          description: 'Doğum gününüz münasibətilə xüsusi endirim!',
          discountPercentage: 20,
          type: 'birthday',
          startDate: today,
          endDate: new Date(today.setDate(today.getDate() + 7)), // Valid for 7 days
          minimumPoints: 0,
          requiresVip: false
        }];
      }
    }
    res.json([...regularOffers, ...birthdayOffers]);
  });

  app.post("/api/offers", async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) {
      return res.sendStatus(401);
    }
    const offer = await storage.createSpecialOffer(req.body);
    res.json(offer);
  });
  app.get("/api/referrals/stats", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const stats = {
      totalReferrals: await storage.getReferralCount(req.user!.id),
      pendingReferrals: await storage.getPendingReferralCount(req.user!.id),
      totalPointsEarned: await storage.getReferralPointsEarned(req.user!.id),
      recentReferrals: await storage.getRecentReferrals(req.user!.id, 5)
    };
    res.json(stats);
  });
  app.post("/api/referrals/track", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const { referralCode } = req.body;
    if (!referralCode) {
      return res.status(400).json({ message: "Referral code is required" });
    }
    const referrer = await storage.getUserByReferralCode(referralCode);
    if (!referrer || referrer.id === req.user!.id) {
      return res.status(400).json({ message: "Invalid referral code" });
    }
    await storage.trackReferral(referrer.id, req.user!.id);
    res.sendStatus(200);
  });
  app.post("/api/social/posts", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const parseResult = insertSocialMediaPostSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json(parseResult.error);
    }
    const post = await storage.createSocialMediaPost({
      ...parseResult.data,
      userId: req.user!.id,
    });
    res.json(post);
  });

  app.get("/api/social/posts", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const posts = await storage.getUserSocialMediaPosts(req.user!.id);
    res.json(posts);
  });

  app.patch("/api/social/handles", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    await storage.updateUserSocialMediaHandles(req.user!.id, req.body);
    res.sendStatus(200);
  });
  app.post("/api/reactions", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const parseResult = insertEmojiReactionSchema.safeParse({
      ...req.body,
      userId: req.user!.id
    });
    if (!parseResult.success) {
      return res.status(400).json(parseResult.error);
    }
    const reaction = await storage.createEmojiReaction(parseResult.data);
    res.status(201).json(reaction);
  });

  app.get("/api/reactions/:productId", async (req, res) => {
    const productId = parseInt(req.params.productId);
    const reactions = await storage.getProductReactions(productId);
    res.json(reactions);
  });

  app.delete("/api/reactions/:productId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    const productId = parseInt(req.params.productId);
    await storage.deleteEmojiReaction(req.user!.id, productId);
    res.sendStatus(204);
  });
  app.get("/api/recommendations", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    try {
      const recommendations = await recommendationService.getRecommendations(req.user!.id);
      res.json(recommendations);
    } catch (error) {
      console.error('Recommendation error:', error);
      res.status(500).json({
        message: "Tövsiyələr alınarkən xəta baş verdi",
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Customer Showcase routes
  app.get("/api/customer-showcases", async (_req, res) => {
    try {
      const showcases = await db.select().from(customerShowcase)
        .orderBy(customerShowcase.createdAt);
      res.json(showcases);
    } catch (error) {
      console.error('Error fetching customer showcases:', error);
      res.status(500).json({ message: "Müştəri nümunələri yüklənmədi" });
    }
  });

  app.post("/api/customer-showcases", async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) {
      return res.sendStatus(401);
    }
    try {
      const parseResult = insertCustomerShowcaseSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json(parseResult.error);
      }
      const [showcase] = await db.insert(customerShowcase)
        .values(parseResult.data)
        .returning();
      res.status(201).json(showcase);
    } catch (error) {
      console.error('Error creating customer showcase:', error);
      res.status(500).json({ message: "Müştəri nümunəsi əlavə edilmədi" });
    }
  });

  // Welcome Wheel Rewards routes
  app.post("/api/welcome-rewards/spin", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    try {
      // Check if user already has a reward
      const existingReward = await db.select()
        .from(welcomeWheelRewards)
        .where(eq(welcomeWheelRewards.userId, req.user!.id))
        .limit(1);

      if (existingReward.length > 0) {
        return res.status(400).json({ message: "Artıq bonus çarxını fırlatmısınız" });
      }

      // Generate random reward (discount or free shipping)
      const rewardType = Math.random() > 0.5 ? 'discount' : 'free_shipping';
      const discountPercentage = rewardType === 'discount'
        ? Math.floor(Math.random() * 31) + 5 // 5-35% discount
        : null;

      const parseResult = insertWelcomeWheelRewardSchema.safeParse({
        userId: req.user!.id,
        rewardType,
        discountPercentage,
        expiresAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days
      });

      if (!parseResult.success) {
        return res.status(400).json(parseResult.error);
      }

      const [reward] = await db.insert(welcomeWheelRewards)
        .values(parseResult.data)
        .returning();

      res.json(reward);
    } catch (error) {
      console.error('Error creating welcome reward:', error);
      res.status(500).json({ message: "Bonus yaradılmadı" });
    }
  });

  // About Page routes
  app.get("/api/about", async (_req, res) => {
    try {
      const content = await db.select()
        .from(aboutPageContent)
        .orderBy(aboutPageContent.order);
      res.json(content);
    } catch (error) {
      console.error('Error fetching about page content:', error);
      res.status(500).json({ message: "Məlumatlar yüklənmədi" });
    }
  });

  app.post("/api/about", async (req, res) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) {
      return res.sendStatus(401);
    }
    try {
      const parseResult = insertAboutPageContentSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json(parseResult.error);
      }
      const [content] = await db.insert(aboutPageContent)
        .values(parseResult.data)
        .returning();
      res.status(201).json(content);
    } catch (error) {
      console.error('Error creating about page content:', error);
      res.status(500).json({ message: "Məlumat əlavə edilmədi" });
    }
  });


  const httpServer = createServer(app);
  return httpServer;
}