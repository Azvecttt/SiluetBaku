import { Twilio } from 'twilio';
import web_push from 'web-push';
import { storage } from '../storage';
import { NotificationPreferences, Order, User } from '@shared/schema';

class NotificationService {
  private twilio: Twilio;

  constructor() {
    // Initialize Twilio client
    this.twilio = new Twilio(process.env.TWILIO_ACCOUNT_SID!, process.env.TWILIO_AUTH_TOKEN!);

    // Initialize web-push
    web_push.setVapidDetails(
      'mailto:' + process.env.VAPID_EMAIL,
      process.env.VAPID_PUBLIC_KEY!,
      process.env.VAPID_PRIVATE_KEY!
    );
  }

  async sendOrderStatusUpdate(order: Order, user: User, status: string) {
    const prefs = await this.getNotificationPreferences(user.id);

    const message = `Sifarişinizin statusu yeniləndi: ${status}`;

    if (prefs?.smsEnabled && user.phoneNumber) {
      await this.sendSMS(user.phoneNumber, message);
    }

    if (prefs?.whatsappEnabled && user.phoneNumber) {
      await this.sendWhatsApp(user.phoneNumber, message);
    }

    if (prefs?.pushEnabled) {
      await this.sendPushNotification(user.id, {
        title: 'Sifariş Statusu',
        body: message
      });
    }
  }

  private async getNotificationPreferences(userId: number): Promise<NotificationPreferences | undefined> {
    return await storage.getNotificationPreferences(userId);
  }

  private async sendSMS(to: string, message: string) {
    try {
      await this.twilio.messages.create({
        body: message,
        to,
        from: process.env.TWILIO_PHONE_NUMBER
      });
    } catch (error) {
      console.error('SMS sending failed:', error);
    }
  }

  private async sendWhatsApp(to: string, message: string) {
    try {
      await this.twilio.messages.create({
        body: message,
        to: `whatsapp:${to}`,
        from: `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER}`
      });
    } catch (error) {
      console.error('WhatsApp message sending failed:', error);
    }
  }

  private async sendPushNotification(userId: number, notification: { title: string, body: string }) {
    const subscriptions = await storage.getPushSubscriptions(userId);

    for (const subscription of subscriptions) {
      try {
        const webPushSubscription = {
          endpoint: subscription.endpoint,
          keys: {
            p256dh: subscription.p256dh,
            auth: subscription.auth
          }
        };

        await web_push.sendNotification(webPushSubscription, JSON.stringify(notification));
      } catch (error) {
        console.error('Push notification failed:', error);
      }
    }
  }
}

export const notificationService = new NotificationService();