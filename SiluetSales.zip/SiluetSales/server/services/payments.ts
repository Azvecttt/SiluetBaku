import Stripe from 'stripe';

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('STRIPE_SECRET_KEY is required');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export async function createPaymentIntent(amount: number): Promise<string> {
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100, // Convert to cents
      currency: 'azn',
      automatic_payment_methods: {
        enabled: true,
      },
    });

    if (!paymentIntent.client_secret) {
      throw new Error('Failed to create payment intent');
    }

    return paymentIntent.client_secret;
  } catch (error) {
    console.error('Error creating payment intent:', error);
    throw error;
  }
}

// Apple Pay payment
export async function createApplePayPayment(amount: number, paymentMethodId: string): Promise<string> {
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100,
      currency: 'azn',
      payment_method: paymentMethodId,
      payment_method_types: ['card'],
      confirm: true,
      payment_method_options: {
        card: {
          request_three_d_secure: 'automatic',
        },
      },
      return_url: `${process.env.VITE_APP_URL || 'https://siluetbaku.repl.co'}/payment-success`,
    });

    if (!paymentIntent.client_secret) {
      throw new Error('Failed to create Apple Pay payment');
    }

    return paymentIntent.client_secret;
  } catch (error) {
    console.error('Error processing Apple Pay payment:', error);
    throw error;
  }
}