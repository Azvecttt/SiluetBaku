import { storage } from '../storage';
import webpush from 'web-push';

if (!process.env.VAPID_PUBLIC_KEY || !process.env.VAPID_PRIVATE_KEY) {
  throw new Error('VAPID keys must be set');
}

webpush.setVapidDetails(
  'mailto:support@siluetbaku.az',
  process.env.VAPID_PUBLIC_KEY,
  process.env.VAPID_PRIVATE_KEY
);

export async function sendPushNotification(content: string, userId: number) {
  try {
    const subscriptions = await storage.getPushSubscriptions(userId);
    
    const notifications = subscriptions.map(subscription => 
      webpush.sendNotification(
        {
          endpoint: subscription.endpoint,
          keys: {
            p256dh: subscription.p256dh,
            auth: subscription.auth,
          }
        },
        JSON.stringify({
          title: 'SiluetBaku Bildiriş',
          body: content,
          icon: '/icon.png',
        })
      )
    );

    await Promise.all(notifications);
  } catch (error) {
    console.error('Error sending push notification:', error);
    throw error;
  }
}
