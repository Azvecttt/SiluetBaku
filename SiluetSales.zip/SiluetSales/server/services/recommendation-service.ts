import OpenAI from 'openai';
import { Order, Product } from '@shared/schema';
import { storage } from '../storage';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Cache tövsiyələri saxlamaq üçün
const recommendationCache = new Map<number, {
  recommendations: Product[];
  timestamp: Date;
}>();

// Cache-in etibarlılıq müddəti (24 saat)
const CACHE_VALIDITY_HOURS = 24;

class RecommendationService {
  private async generatePrompt(userId: number): Promise<string> {
    // İstifadəçinin keçmiş sifarişlərini əldə et
    const orders = await storage.getOrders(userId);
    const products = await storage.getProducts();

    // Sifarişləri mətn formatına çevir
    const orderHistory = orders.map(order => {
      const product = products.find(p => p.id === order.productId);
      return `${product?.name} (${order.size || 'standart ölçü'})`;
    }).join(', ');

    return `İstifadəçinin əvvəlki sifarişləri: ${orderHistory || 'Sifariş yoxdur'}

    Məhsullar:
    ${products.map(p => `- ${p.name}: ${p.description}`).join('\n')}

    Bu istifadəçi üçün ən uyğun 3 məhsulu təklif edin. Cavabı bu formatda verin:
    1. [məhsul_adı]: [səbəb]
    2. [məhsul_adı]: [səbəb]
    3. [məhsul_adı]: [səbəb]`;
  }

  private async getRecommendationsFromAI(userId: number): Promise<Product[]> {
    const prompt = await this.generatePrompt(userId);
    
    const completion = await openai.chat.completions.create({
      messages: [
        { 
          role: "system", 
          content: "Siz SiluetBaku-nun AI məsləhətçisisiniz. Sifarişləri analiz edib, müştərilərə fərdi tövsiyələr verirsiniz." 
        },
        { role: "user", content: prompt }
      ],
      model: "gpt-3.5-turbo",
    });

    const response = completion.choices[0].message.content;
    const products = await storage.getProducts();

    // AI cavabından məhsul adlarını çıxarıb, məhsul obyektlərini tap
    const recommendedProducts = response!.split('\n')
      .map(line => {
        const match = line.match(/\d\.\s+([^:]+):/);
        return match ? match[1].trim() : null;
      })
      .filter(name => name !== null)
      .map(name => products.find(p => p.name.toLowerCase() === name!.toLowerCase()))
      .filter(p => p !== undefined) as Product[];

    return recommendedProducts;
  }

  async getRecommendations(userId: number): Promise<Product[]> {
    // Cache-də mövcud tövsiyələri yoxla
    const cached = recommendationCache.get(userId);
    const now = new Date();

    if (cached && 
        (now.getTime() - cached.timestamp.getTime()) < CACHE_VALIDITY_HOURS * 60 * 60 * 1000) {
      return cached.recommendations;
    }

    // Yeni tövsiyələr əldə et
    const recommendations = await this.getRecommendationsFromAI(userId);

    // Cache-i yenilə
    recommendationCache.set(userId, {
      recommendations,
      timestamp: now
    });

    return recommendations;
  }

  // Cache-i təmizlə
  clearCache(userId?: number) {
    if (userId) {
      recommendationCache.delete(userId);
    } else {
      recommendationCache.clear();
    }
  }
}

export const recommendationService = new RecommendationService();
