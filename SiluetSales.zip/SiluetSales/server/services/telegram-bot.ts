import TelegramBot from 'node-telegram-bot-api';
import { log } from '../vite';
import { storage } from '../storage';
import { db } from '../db';
import { eq } from 'drizzle-orm';
import { adminChatIds, supportMessages } from '@shared/schema';

let botInstance: TelegramBot | null = null;

export function initializeBot() {
  if (!process.env.TELEGRAM_BOT_TOKEN) {
    throw new Error('TELEGRAM_BOT_TOKEN is not set');
  }

  if (botInstance) {
    botInstance.stopPolling();
    botInstance = null;
  }

  try {
    botInstance = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { 
      polling: true,
      filepath: false
    });

    // Handle admin registration
    botInstance.onText(/\/register_admin/, async (msg) => {
      try {
        const chatId = msg.chat.id;

        // Save admin chat ID to database
        await db.insert(adminChatIds).values({
          chatId: chatId.toString(),
          username: msg.from?.username || 'unknown',
          registeredAt: new Date()
        }).onConflictDoNothing();

        await botInstance!.sendMessage(chatId, 'Bu chat admin olaraq qeydiyyata alındı. Bundan sonra bütün sifariş və müştəri mesajları buraya göndəriləcək.');
        log(`New admin registered with chat ID: ${chatId}`);
      } catch (error) {
        log(`Error registering admin: ${error}`);
      }
    });

    // Handle admin replies
    botInstance.on('message', async (msg) => {
      try {
        if (msg.text?.startsWith('/')) return; // Ignore commands

        const chatId = msg.chat.id;

        // Check if this chat is an admin chat
        const adminChat = await db.select()
          .from(adminChatIds)
          .where(eq(adminChatIds.chatId, chatId.toString()))
          .limit(1);

        // If this is an admin chat and it's a reply to a message
        if (adminChat.length && msg.reply_to_message) {
          // Extract user ID from the original message
          const originalMessage = msg.reply_to_message.text;
          const match = originalMessage?.match(/Kimden: .+ \(ID: (\d+)\)/);

          if (match) {
            const userId = parseInt(match[1]);
            log(`Processing admin reply for user ${userId}: ${msg.text}`);

            // Save admin reply to database
            const [message] = await db.insert(supportMessages)
              .values({
                userId: userId,
                content: msg.text || '',
                isAdmin: true,
                createdAt: new Date()
              })
              .returning();

            log(`Admin reply saved to database: ${JSON.stringify(message)}`);
            await botInstance!.sendMessage(chatId, 'Cavabınız müştəriyə göndərildi ✓');
          } else {
            await botInstance!.sendMessage(chatId, 'Xəta: Müştəri ID-si tapılmadı. Zəhmət olmasa müştəri mesajına cavab verin.');
          }
        }
      } catch (error) {
        log(`Error handling message: ${error}`);
      }
    });

    // Handle polling errors gracefully
    botInstance.on('polling_error', (error) => {
      log(`Telegram polling error: ${error.message}`);
      if (error.message.includes('409')) {
        botInstance?.stopPolling().then(() => {
          setTimeout(() => {
            botInstance?.startPolling();
          }, 5000);
        });
      }
    });

    log('Telegram bot initialized successfully');
    return botInstance;
  } catch (error) {
    log(`Failed to initialize Telegram bot: ${error}`);
    throw error;
  }
}

export async function sendAdminMessage(message: string) {
  const bot = initializeBot();
  if (!bot) {
    log("Bot not initialized");
    return;
  }

  try {
    // Get all admin chats from database
    const admins = await db.select().from(adminChatIds);

    if (admins.length === 0) {
      log("No admin chats registered");
      return;
    }

    for (const admin of admins) {
      try {
        await bot.sendMessage(parseInt(admin.chatId), message);
        log(`Message sent to admin ${admin.chatId}`);
      } catch (error) {
        log(`Error sending message to admin ${admin.chatId}: ${error}`);
      }
    }
  } catch (error) {
    log(`Error in sendAdminMessage: ${error}`);
  }
}

export async function sendOrderNotification(orderId: number, status: string, details: string) {
  const message = `🛍️ Yeni Sifariş Bildirişi\n\nSifariş ID: ${orderId}\nStatus: ${status}\n\nDetallar:\n${details}`;
  await sendAdminMessage(message);
}

export async function sendSupportMessage(userId: number, message: string) {
  try {
    const user = await storage.getUser(userId);
    const userInfo = user ? `${user.username} (ID: ${user.id})` : `User ID: ${userId}`;

    const formattedMessage = `💬 Müştəri Dəstək Mesajı\n\nKimden: ${userInfo}\nMesaj: ${message}`;
    await sendAdminMessage(formattedMessage);
  } catch (error) {
    log(`Error in sendSupportMessage: ${error}`);
  }
}

// Initialize bot when module is loaded
initializeBot();

export const bot = botInstance;