import TelegramBot from "node-telegram-bot-api";
import { Order, Product, insertOrderSchema } from "@shared/schema";
import { storage } from "../storage";

// Burada admin telefon nömrələrini Telegram chat ID-ləri ilə əvəz edək
const ADMIN_CHAT_IDS = ["6377553430", "1242678629"]; // Admin Telegram chat ID-si

if (!process.env.TELEGRAM_BOT_TOKEN) {
  throw new Error("TELEGRAM_BOT_TOKEN is required");
}

const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: true });

// Store customer order state
const customerOrders = new Map();

// Store customer support chat states
const customerSupport = new Map();

// Error handling wrapper for sending messages
async function safeSendMessage(chatId: string | number, message: string, options = {}) {
  try {
    await bot.sendMessage(chatId, message, options);
  } catch (error) {
    console.error(`Failed to send message to ${chatId}:`, error);
  }
}

// Chat ID-ni görmək üçün əmr əlavə edək
bot.onText(/\/chatid/, async (msg) => {
  const chatId = msg.chat.id;
  console.log("User requested Chat ID:", chatId); // Debug log
  await safeSendMessage(chatId, `Sizin Chat ID: ${chatId}`);
});


// Handle /start command
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  if (ADMIN_CHAT_IDS.includes(chatId.toString())) {
    await safeSendMessage(chatId, `
SiluetBaku Admin Bot-a xoş gəlmisiniz! 👋

İdarə əmrləri:
/orders - Bütün sifarişlərə baxmaq
/pending - Gözləmədə olan sifarişlər
/processing - Hazırlanan sifarişlər
/active_chats - Aktiv müştəri söhbətləri
/help - Kömək

Sifarişlər haqqında:
/order_[Sifariş nömrəsi] - Məsələn: /order_1

Müştəri dəstəyi:
- Müştəriyə cavab vermək üçün onların mesajını reply edərək yazın
- Aktiv söhbətləri görmək üçün /active_chats yazın
- Söhbəti bağlamaq üçün /close_chat_[Müştəri ID] yazın
    `);
  } else {
    await safeSendMessage(chatId, `
SiluetBaku-ya xoş gəlmisiniz! 🎉

Mənimlə nə edə bilərsiniz:
/products - Məhsullarımıza baxmaq
/order - Yeni sifariş vermək
/status - Sifarişinizin vəziyyətini yoxlamaq
/help - Kömək üçün
/support - Bizimlə əlaqə saxlamaq üçün

Bütün sifarişləriniz avtomatik olaraq sistemə yüklənəcək və sizə sifariş nömrəsi veriləcək.
    `);
  }
});

// Handle /help command
bot.onText(/\/help/, async (msg) => {
  const chatId = msg.chat.id;
  if (ADMIN_CHAT_IDS.includes(chatId.toString())) {
    await safeSendMessage(chatId, `
Admin Əmrləri 🛠️:

📋 Sifarişləri görmək:
/orders - Bütün sifarişlər
/pending - Gözləyən sifarişlər
/processing - Hazırlanan sifarişlər
/today - Bu günkü sifarişlər
/weekly - Bu həftəki sifarişlər

👥 Müştəri dəstəyi:
/active_chats - Aktiv müştəri söhbətləri
/close_chat_[ID] - Söhbəti bağlamaq

🔍 Spesifik sifariş:
/order_[Sifariş nömrəsi] - Məsələn: /order_1
/status_[Sifariş nömrəsi]_[Status] - Məsələn: /status_1_processing

Statuslar:
- processing (Hazırlanır)
- shipped (Göndərilib)
- delivered (Çatdırılıb)
    `);
  } else {
    await safeSendMessage(chatId, `
Kömək Mərkəzi 💡

🛍️ Sifariş vermək üçün:
1. /products - Məhsullarımıza baxın
2. /order - Sifariş vermək üçün bura basın

📊 Sifarişinizi izləmək üçün:
/status - Sifariş nömrənizi yazaraq statusu öyrənin

💬 Müştəri dəstəyi:
/support - Bizimlə əlaqə saxlamaq üçün
/end_chat - Söhbəti bitirmək üçün

❌ Əməliyyatı dayandırmaq üçün:
/cancel - Cari əməliyyatı ləğv edin
    `);
  }
});

// Handle /support command for customers
bot.onText(/\/support/, async (msg) => {
  const chatId = msg.chat.id;
  if (!ADMIN_CHAT_IDS.includes(chatId.toString())) {
    customerSupport.set(chatId, { active: true });
    await safeSendMessage(chatId, `
Müştəri dəstəyinə xoş gəlmisiniz! 👋
Zəhmət olmasa sualınızı yazın, operatorlarımız sizə qısa zamanda cavab verəcəklər.
Söhbəti bitirmək üçün /end_chat yazın.
    `);

    // Notify admins about new support request
    for (const adminId of ADMIN_CHAT_IDS) {
      await safeSendMessage(adminId, `
📩 Yeni müştəri dəstəyi müraciəti:
👤 İstifadəçi ID: ${chatId}
⏰ Vaxt: ${new Date().toLocaleString('az-AZ')}
      `);
    }
  }
});

// Handle /end_chat command for customers
bot.onText(/\/end_chat/, async (msg) => {
  const chatId = msg.chat.id;
  if (!ADMIN_CHAT_IDS.includes(chatId.toString())) {
    customerSupport.delete(chatId);
    await safeSendMessage(chatId, "Söhbət bitdi. Təşəkkür edirik! 🙏");

    // Notify admins
    for (const adminId of ADMIN_CHAT_IDS) {
      await safeSendMessage(adminId, `
❌ Müştəri söhbəti bağlandı:
👤 İstifadəçi ID: ${chatId}
⏰ Vaxt: ${new Date().toLocaleString('az-AZ')}
      `);
    }
  }
});

// Handle /active_chats command for admins
bot.onText(/\/active_chats/, async (msg) => {
  const chatId = msg.chat.id;
  if (ADMIN_CHAT_IDS.includes(chatId.toString())) {
    const activeChats = Array.from(customerSupport.entries())
      .filter(([_, state]) => state.active)
      .map(([customerId, _]) => customerId);

    if (activeChats.length === 0) {
      await safeSendMessage(chatId, "📭 Hal-hazırda aktiv müştəri söhbəti yoxdur.");
      return;
    }

    let message = "🗨️ Aktiv müştəri söhbətləri:\n\n";
    activeChats.forEach((customerId) => {
      message += `👤 Müştəri ID: ${customerId}\n`;
    });

    await safeSendMessage(chatId, message);
  }
});

// Handle /close_chat command for admins
bot.onText(/\/close_chat_(\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (ADMIN_CHAT_IDS.includes(chatId.toString()) && match) {
    const customerId = match[1];
    if (customerSupport.has(Number(customerId))) {
      customerSupport.delete(Number(customerId));
      await safeSendMessage(chatId, `✅ ${customerId} nömrəli müştəri söhbəti bağlandı.`);
      await safeSendMessage(Number(customerId), "Operator söhbəti bağladı. Təşəkkür edirik! 🙏");
    } else {
      await safeSendMessage(chatId, "❌ Bu ID ilə aktiv söhbət tapılmadı.");
    }
  }
});

// Handle regular messages for customer support
bot.on('message', async (msg) => {
  if (!msg.text || msg.text.startsWith('/')) return;

  const chatId = msg.chat.id;

  // If customer message and support chat is active
  if (!ADMIN_CHAT_IDS.includes(chatId.toString()) && customerSupport.get(chatId)?.active) {
    // Forward message to all admins
    for (const adminId of ADMIN_CHAT_IDS) {
      await safeSendMessage(adminId, `
📨 Müştəridən mesaj:
👤 Müştəri ID: ${chatId}
💭 Mesaj: ${msg.text}

Cavab vermək üçün bu mesajı reply edərək yazın.
      `);
    }
    return;
  }

  // If admin is replying to a customer
  if (ADMIN_CHAT_IDS.includes(chatId.toString()) && msg.reply_to_message) {
    const customerIdMatch = msg.reply_to_message.text.match(/👤 Müştəri ID: (\d+)/);
    if (customerIdMatch) {
      const customerId = Number(customerIdMatch[1]);
      if (customerSupport.has(customerId)) {
        await safeSendMessage(customerId, `
👨‍💼 Operator cavabı:
${msg.text}
        `);
        await safeSendMessage(chatId, "✅ Cavabınız müştəriyə göndərildi.");
      } else {
        await safeSendMessage(chatId, "❌ Bu müştəri ilə söhbət artıq bağlanıb.");
      }
    }
  }
});

// Customer: Show products
bot.onText(/\/products/, async (msg) => {
  const chatId = msg.chat.id;
  if (!ADMIN_CHAT_IDS.includes(chatId.toString())) {
    const products = await storage.getProducts();
    let message = "🎨 Məhsullarımız:\n\n";

    for (const product of products) {
      message += `📦 ${product.name}\n`;
      message += `💰 Qiymət: ${product.basePrice} AZN\n`;
      if (product.sizes && product.sizes.length > 0) {
        message += `📏 Ölçülər: ${product.sizes.join(', ')}\n`;
      }
      if (product.hasLipa) {
        message += `✨ Lipa əlavə edilə bilər: +${product.lipaPrice} AZN\n`;
      }
      if (product.description) {
        message += `📝 ${product.description}\n`;
      }
      message += `\n`;
    }

    message += "\n🛍️ Sifariş vermək üçün /order yazın";
    await safeSendMessage(chatId, message);
  }
});

// Customer: Start order process
bot.onText(/\/order/, async (msg) => {
  const chatId = msg.chat.id;
  if (!ADMIN_CHAT_IDS.includes(chatId.toString())) {
    const products = await storage.getProducts();
    customerOrders.set(chatId, { step: 'product_selection' });

    const keyboard = products.map(p => [{
      text: `${p.name} - ${p.basePrice} AZN`,
      callback_data: `select_product_${p.id}`
    }]);

    await safeSendMessage(chatId, "Zəhmət olmasa məhsul seçin:", {
      reply_markup: {
        inline_keyboard: keyboard
      }
    });
  }
});

// Handle callback queries
bot.on('callback_query', async (query) => {
  const chatId = query.message?.chat.id;
  if (!chatId) return;

  if (query.data?.startsWith('select_product_')) {
    const productId = parseInt(query.data.split('_')[2]);
    const products = await storage.getProducts();
    const product = products.find(p => p.id === productId);

    if (product) {
      customerOrders.set(chatId, {
        step: 'collecting_details',
        productId,
        product
      });

      let message = "Sifarişinizi tamamlamaq üçün zəhmət olmasa aşağıdakı məlumatları yazın:\n\n";
      message += "1️⃣ Əlaqə nömrənizi yazın (məs: +994501234567):";

      await safeSendMessage(chatId, message);
    }
  }
});

// Handle text messages for order details
bot.on('message', async (msg) => {
  if (!msg.text || msg.text.startsWith('/')) return;

  const chatId = msg.chat.id;
  if (ADMIN_CHAT_IDS.includes(chatId.toString())) return;

  const orderState = customerOrders.get(chatId);
  if (!orderState) return;

  switch (orderState.step) {
    case 'collecting_details':
      if (!orderState.phoneNumber) {
        orderState.phoneNumber = msg.text;
        orderState.step = 'address';
        await safeSendMessage(chatId, "2️⃣ Çatdırılma ünvanını tam şəkildə yazın:");
      } else if (!orderState.address) {
        orderState.address = msg.text;
        orderState.step = 'quantity';
        await safeSendMessage(chatId, "3️⃣ Neçə ədəd istəyirsiniz? (rəqəmlə yazın)");
      }
      break;

    case 'quantity':
      const quantity = parseInt(msg.text);
      if (isNaN(quantity) || quantity < 1) {
        await safeSendMessage(chatId, "⚠️ Zəhmət olmasa düzgün rəqəm daxil edin.");
        return;
      }

      try {
        const order = await storage.createOrder({
          productId: orderState.productId,
          quantity,
          phoneNumber: orderState.phoneNumber,
          address: orderState.address,
          hasLipa: false,
          userId: 0, // Guest user
          totalPrice: orderState.product.basePrice * quantity,
          customerImage: null,
          size: null
        });

        customerOrders.delete(chatId);

        await safeSendMessage(chatId, `
✅ Sifarişiniz uğurla qəbul edildi!

🔢 Sifariş nömrəniz: #${order.id}
📦 Məhsul: ${orderState.product.name}
📊 Miqdar: ${quantity} ədəd
💰 Ümumi məbləğ: ${order.totalPrice} AZN

ℹ️ Sifarişinizin statusunu yoxlamaq üçün /status yazıb, sifariş nömrənizi (#${order.id}) daxil edə bilərsiniz.

Təşəkkür edirik! 🙏
        `);
      } catch (error) {
        await safeSendMessage(chatId, "❌ Xəta baş verdi. Zəhmət olmasa yenidən cəhd edin.");
        customerOrders.delete(chatId);
      }
      break;
  }
});

// Customer: Check order status
bot.onText(/\/status/, async (msg) => {
  const chatId = msg.chat.id;
  if (!ADMIN_CHAT_IDS.includes(chatId.toString())) {
    await safeSendMessage(chatId, "Zəhmət olmasa sifariş nömrənizi yazın (#-siz):");
    customerOrders.set(chatId, { step: 'checking_status' });
  }
});

// Handle status check
bot.on('message', async (msg) => {
  if (!msg.text || msg.text.startsWith('/')) return;

  const chatId = msg.chat.id;
  const orderState = customerOrders.get(chatId);

  if (orderState?.step === 'checking_status') {
    const orderId = parseInt(msg.text);
    if (isNaN(orderId)) {
      await safeSendMessage(chatId, "⚠️ Zəhmət olmasa düzgün sifariş nömrəsi daxil edin.");
      return;
    }

    const orders = await storage.getOrders();
    const order = orders.find(o => o.id === orderId);

    if (order) {
      const message = await formatOrderMessage(order);
      await safeSendMessage(chatId, message, { parse_mode: "HTML" });
    } else {
      await safeSendMessage(chatId, "❌ Bu nömrə ilə sifariş tapılmadı.");
    }

    customerOrders.delete(chatId);
  }
});

// Handle /orders command
bot.onText(/\/orders/, async (msg) => {
  const chatId = msg.chat.id;
  if (ADMIN_CHAT_IDS.includes(chatId.toString())) {
    const orders = await storage.getOrders();
    if (orders.length === 0) {
      await safeSendMessage(chatId, "📭 Hal-hazırda heç bir sifariş yoxdur.");
      return;
    }

    for (const order of orders.slice(-5)) { // Show last 5 orders
      const message = await formatOrderMessage(order);
      await safeSendMessage(chatId, message, { parse_mode: "HTML" });
    }
  }
});

// Handle /pending command
bot.onText(/\/pending/, async (msg) => {
  const chatId = msg.chat.id;
  if (ADMIN_CHAT_IDS.includes(chatId.toString())) {
    const orders = await storage.getOrders();
    const pendingOrders = orders.filter(o => o.status === "pending");

    if (pendingOrders.length === 0) {
      await safeSendMessage(chatId, "📭 Hal-hazırda gözləyən sifariş yoxdur.");
      return;
    }

    for (const order of pendingOrders) {
      const message = await formatOrderMessage(order);
      await safeSendMessage(chatId, message, { parse_mode: "HTML" });
    }
  }
});

// Handle /processing command
bot.onText(/\/processing/, async (msg) => {
  const chatId = msg.chat.id;
  if (ADMIN_CHAT_IDS.includes(chatId.toString())) {
    const orders = await storage.getOrders();
    const processingOrders = orders.filter(o => o.status === "processing");

    if (processingOrders.length === 0) {
      await safeSendMessage(chatId, "📭 Hal-hazırda hazırlanan sifariş yoxdur.");
      return;
    }

    for (const order of processingOrders) {
      const message = await formatOrderMessage(order);
      await safeSendMessage(chatId, message, { parse_mode: "HTML" });
    }
  }
});

// Handle /today command
bot.onText(/\/today/, async (msg) => {
    const chatId = msg.chat.id;
    if (ADMIN_CHAT_IDS.includes(chatId.toString())) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date();
        tomorrow.setDate(today.getDate() + 1);
        tomorrow.setHours(0, 0, 0, 0);

        const orders = await storage.getOrders();
        const todayOrders = orders.filter(o => o.createdAt >= today.getTime() && o.createdAt < tomorrow.getTime());

        if (todayOrders.length === 0) {
            await safeSendMessage(chatId, "📭 Bu gün sifariş yoxdur.");
            return;
        }

        for (const order of todayOrders) {
            const message = await formatOrderMessage(order);
            await safeSendMessage(chatId, message, { parse_mode: "HTML" });
        }
    }
});

// Handle /weekly command
bot.onText(/\/weekly/, async (msg) => {
    const chatId = msg.chat.id;
    if (ADMIN_CHAT_IDS.includes(chatId.toString())) {
        const today = new Date();
        const firstDay = new Date(today.setDate(today.getDate() - today.getDay()));
        const lastDay = new Date(firstDay);
        lastDay.setDate(firstDay.getDate() + 7);

        const orders = await storage.getOrders();
        const weeklyOrders = orders.filter(o => o.createdAt >= firstDay.getTime() && o.createdAt < lastDay.getTime());

        if (weeklyOrders.length === 0) {
            await safeSendMessage(chatId, "📭 Bu həftə sifariş yoxdur.");
            return;
        }

        for (const order of weeklyOrders) {
            const message = await formatOrderMessage(order);
            await safeSendMessage(chatId, message, { parse_mode: "HTML" });
        }
    }
});


// Handle specific order info request
bot.onText(/\/order_(\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (ADMIN_CHAT_IDS.includes(chatId.toString()) && match) {
    const orderId = parseInt(match[1]);
    const orders = await storage.getOrders();
    const order = orders.find(o => o.id === orderId);

    if (!order) {
      await safeSendMessage(chatId, `❌ ${orderId} nömrəli sifariş tapılmadı.`);
      return;
    }

    const message = await formatOrderMessage(order);
    await safeSendMessage(chatId, message, { parse_mode: "HTML" });
  }
});

// Handle status update command
bot.onText(/\/status_(\d+)_(\w+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (ADMIN_CHAT_IDS.includes(chatId.toString()) && match) {
    const orderId = parseInt(match[1]);
    const newStatus = match[2];

    try {
      const updatedOrder = await storage.updateOrderStatus(orderId, newStatus);
      await safeSendMessage(
        chatId,
        `✅ Sifariş #${orderId} statusu yeniləndi: ${newStatus}`,
        { parse_mode: "HTML" }
      );
    } catch (error) {
      await safeSendMessage(
        chatId,
        `❌ Xəta: Sifariş #${orderId} statusu yenilənə bilmədi.`
      );
    }
  }
});

export async function sendOrderNotification(order: Order) {
  try {
    const product = await storage.getProducts().then(products =>
      products.find(p => p.id === order.productId)
    );

    if (!product) {
      console.error(`Product not found for order ${order.id}`);
      return;
    }

    const message = await formatOrderMessage(order);

    for (const chatId of ADMIN_CHAT_IDS) {
      await safeSendMessage(chatId, message, { parse_mode: "HTML" });
    }
  } catch (error) {
    console.error("Failed to send Telegram notification:", error);
  }
}

async function formatOrderMessage(order: Order): Promise<string> {
  const product = await storage.getProducts().then(products =>
    products.find(p => p.id === order.productId)
  );

  const statusEmoji = {
    pending: "⏳",
    processing: "🔄",
    shipped: "🚚",
    delivered: "✅"
  }[order.status] || "❓";

  const statusText = {
    pending: "Gözləmədə",
    processing: "Hazırlanır",
    shipped: "Göndərilib",
    delivered: "Çatdırılıb"
  }[order.status] || order.status;

  return `
🔔 <b>Sifariş #${order.id}</b>

📦 Məhsul: ${product?.name || "Naməlum məhsul"}
📏 Ölçü: ${order.size || "Təyin edilməyib"}
🎨 Lipa: ${order.hasLipa ? "Bəli" : "Xeyr"}
🔢 Miqdar: ${order.quantity} ədəd
💰 Ümumi məbləğ: ${order.totalPrice} AZN

📍 Çatdırılma ünvanı: ${order.address}
📱 Əlaqə nömrəsi: ${order.phoneNumber}

⏰ Sifariş tarixi: ${new Date(order.createdAt).toLocaleString('az-AZ')}
📊 Status: ${statusEmoji} ${statusText}

${ADMIN_CHAT_IDS.includes(order.phoneNumber) ? `
🔄 Status yeniləmək üçün:
/status_${order.id}_processing - Hazırlanır
/status_${order.id}_shipped - Göndərilib
/status_${order.id}_delivered - Çatdırılıb` : ''}
`;
}