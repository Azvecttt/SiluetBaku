import {
  users, products, orders, onboardingSteps, userProgress, rewards, userRewards,
  notifications, orderStatusHistory, pushSubscriptions, referralRewards,
  specialOffers, socialMediaPosts, emojiReactions, // Added emojiReactions
  type User, type InsertUser, type Product, type Order, type OnboardingStep,
  type UserProgress, type Reward, type UserReward, type Notification,
  type OrderStatusHistory, type PushSubscription, type ReferralReward,
  type SpecialOffer, type SocialMediaPost, type EmojiReaction, type InsertEmojiReaction,
  type NotificationPreferences, // Added NotificationPreferences type
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import { sendOrderNotification } from "./services/telegram";
import { sendWhatsAppMessage } from "./services/whatsapp";
import { sendSMS } from "./services/sms";
import { sendPushNotification } from "./services/push-notifications";

const scryptAsync = promisify(scrypt);
const PostgresSessionStore = connectPg(session);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getProducts(): Promise<Product[]>;
  getOrders(userId?: number): Promise<Order[]>;
  createOrder(order: Omit<Order, "id" | "status" | "createdAt">): Promise<Order>;
  updateOrderStatus(orderId: number, status: string): Promise<Order>;
  sessionStore: session.Store;
  createProduct(product: Omit<Product, "id">): Promise<Product>;
  updateProduct(id: number, updates: Partial<Omit<Product, "id">>): Promise<Product>;
  deleteProduct(id: number): Promise<void>;

  // New methods for onboarding and rewards
  getOnboardingSteps(): Promise<OnboardingStep[]>;
  getUserProgress(userId: number): Promise<UserProgress[]>;
  completeOnboardingStep(userId: number, stepId: number): Promise<void>;
  getRewards(): Promise<Reward[]>;
  getUserRewards(userId: number): Promise<UserReward[]>;
  claimReward(userId: number, rewardId: number): Promise<void>;
  updateUserPoints(userId: number, points: number): Promise<void>;

  // Notification methods
  createNotification(notification: Omit<Notification, "id" | "createdAt" | "sentAt">): Promise<Notification>;
  getUserNotifications(userId: number): Promise<Notification[]>;
  markNotificationSent(notificationId: number): Promise<void>;

  // Order tracking methods
  addOrderStatusHistory(statusHistory: Omit<OrderStatusHistory, "id" | "timestamp">): Promise<OrderStatusHistory>;
  getOrderStatusHistory(orderId: number): Promise<OrderStatusHistory[]>;
  updateOrderLocation(orderId: number, location: any): Promise<void>;

  // Push notification methods
  savePushSubscription(subscription: Omit<PushSubscription, "id" | "createdAt">): Promise<PushSubscription>;
  getPushSubscriptions(userId: number): Promise<PushSubscription[]>;

  // Referral methods
  createReferralReward(reward: Omit<ReferralReward, "id" | "createdAt">): Promise<ReferralReward>;
  getReferralRewards(userId: number): Promise<ReferralReward[]>;
  generateReferralCode(userId: number): Promise<string>;

  // Special offers methods
  createSpecialOffer(offer: Omit<SpecialOffer, "id">): Promise<SpecialOffer>;
  getActiveSpecialOffers(): Promise<SpecialOffer[]>;
  getUserSpecialOffers(userId: number): Promise<SpecialOffer[]>;

  // Social media methods
  createSocialMediaPost(post: Omit<SocialMediaPost, "id" | "createdAt">): Promise<SocialMediaPost>;
  getUserSocialMediaPosts(userId: number): Promise<SocialMediaPost[]>;
  updateUserSocialMediaHandles(userId: number, handles: any): Promise<void>;

  // Emoji reaction methods
  createEmojiReaction(reaction: InsertEmojiReaction): Promise<EmojiReaction>;
  getProductReactions(productId: number): Promise<EmojiReaction[]>;
  getUserReactions(userId: number): Promise<EmojiReaction[]>;
  deleteEmojiReaction(userId: number, productId: number): Promise<void>;

  // New referral methods
  getUserReferralCode(userId: number): Promise<string | null>;
  getReferralCount(userId: number): Promise<number>;
  getPendingReferralCount(userId: number): Promise<number>;
  getReferralPointsEarned(userId: number): Promise<number>;
  getRecentReferrals(userId: number, limit: number): Promise<{ username: string; date: Date }[]>;
  trackReferral(referrerId: number, referredId: number): Promise<void>;
  getUserByReferralCode(code: string): Promise<User | undefined>;

  // Add these new methods
  getNotificationPreferences(userId: number): Promise<NotificationPreferences | undefined>;
  saveNotificationPreferences(userId: number, preferences: Omit<NotificationPreferences, "id">): Promise<NotificationPreferences>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });

    // Seed admin users and initial data
    this.seedAdminUsers();
    this.seedProducts();
    this.seedOnboardingSteps();
    this.seedRewards();
  }

  private async seedAdminUsers() {
    const existingUsers = await db.select().from(users);
    if (existingUsers.length === 0) {
      const adminUsers = [
        {
          username: "Azvect",
          password: await hashPassword("Azvect2611"),
          is_admin: true,
          phone_number: "+994103332535",
          email: "admin1@siluetbaku.az",
          points: 0,
          birth_date: new Date("1990-01-01"), // Default birth date
        },
        {
          username: "Alina",
          password: await hashPassword("Alina2611"),
          is_admin: true,
          phone_number: "+994104440934",
          email: "admin2@siluetbaku.az",
          points: 0,
          birth_date: new Date("1990-01-01"), // Default birth date
        },
      ];

      for (const admin of adminUsers) {
        await db.insert(users).values(admin);
      }
    }
  }

  private async seedProducts() {
    const existingProducts = await this.getProducts();
    if (existingProducts.length === 0) {
      const productsList = [
        {
          name: "Siluet",
          type: "siluet",
          basePrice: 50,
          sizes: ["120sm", "100sm", "80sm", "60sm", "40sm"],
          colors: ["Black", "White", "Red", "Blue"],
          hasLipa: true,
          lipaPrice: 10,
          requiresImage: false,
          description: "Custom silhouette with various size options",
        },
        {
          name: "Poster",
          type: "poster",
          basePrice: 30,
          sizes: ["40x30", "70x50", "90x70"],
          colors: [],
          hasLipa: false,
          requiresImage: true,
          description: "Custom poster print in multiple sizes",
        },
        {
          name: "Brelok",
          type: "brelok",
          basePrice: 15,
          sizes: [],
          colors: [],
          hasLipa: false,
          requiresImage: true,
          description: "Custom keychain with your image",
        },
      ];

      // Insert products one by one to avoid array insert issues
      for (const product of productsList) {
        await db.insert(products).values(product);
      }
    }
  }

  private async seedOnboardingSteps() {
    const existingSteps = await db.select().from(onboardingSteps);
    if (existingSteps.length === 0) {
      const steps = [
        {
          title: "Profili tamamla",
          description: "Şəxsi məlumatlarınızı əlavə edin və bonus xal qazanın",
          points: 50,
          order: 1,
          icon: "User",
        },
        {
          title: "İlk sifarişinizi verin",
          description: "İlk sifarişinizi yaradın və xüsusi endirim əldə edin",
          points: 100,
          order: 2,
          icon: "ShoppingBag",
        },
        {
          title: "Sosial mediada bizi izləyin",
          description: "Sosial şəbəkələrdə bizi izləyərək xal toplayın",
          points: 50,
          order: 3,
          icon: "Share2",
        },
      ];

      for (const step of steps) {
        await db.insert(onboardingSteps).values(step);
      }
    }
  }

  private async seedRewards() {
    const existingRewards = await db.select().from(rewards);
    if (existingRewards.length === 0) {
      const rewardsList = [
        {
          name: "10% Endirim Kuponu",
          description: "Növbəti sifarişinizdə 10% endirim əldə edin",
          pointsRequired: 100,
          type: "discount",
          value: 10,
          icon: "Percent",
        },
        {
          name: "Pulsuz Çatdırılma",
          description: "Bir dəfəlik pulsuz çatdırılma xidməti",
          pointsRequired: 200,
          type: "free_delivery",
          value: 0,
          icon: "Truck",
        },
        {
          name: "VIP Status",
          description: "Xüsusi VIP müştəri statusu və əlavə üstünlüklər",
          pointsRequired: 500,
          type: "status",
          value: 0,
          icon: "Crown",
        },
      ];

      for (const reward of rewardsList) {
        await db.insert(rewards).values(reward);
      }
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        username: insertUser.username,
        password: insertUser.password,
        phoneNumber: insertUser.phoneNumber || null,
        email: insertUser.email || null,
        isAdmin: false,
        points: 0,
        onboardingCompleted: false,
        birthDate: insertUser.birthDate ? new Date(insertUser.birthDate) : null,
        socialMediaHandles: insertUser.socialMediaHandles || null,
      })
      .returning();
    return user;
  }

  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getOrders(userId?: number): Promise<Order[]> {
    let query = db.select().from(orders);
    if (userId) {
      query = query.where(eq(orders.userId, userId));
    }
    return await query;
  }

  async createOrder(order: Omit<Order, "id" | "status" | "createdAt">): Promise<Order> {
    const [newOrder] = await db
      .insert(orders)
      .values({
        ...order,
        status: "pending",
      })
      .returning();

    // Send Telegram notification for new order
    await sendOrderNotification(newOrder);

    return newOrder;
  }

  async updateOrderStatus(orderId: number, status: string): Promise<Order> {
    const [updatedOrder] = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, orderId))
      .returning();

    if (!updatedOrder) {
      throw new Error("Order not found");
    }

    // Send Telegram notification for status update
    await sendOrderNotification(updatedOrder);

    return updatedOrder;
  }

  async createProduct(product: Omit<Product, "id">): Promise<Product> {
    try {
      // Ensure colors is properly formatted as JSONB
      const formattedProduct = {
        ...product,
        colors: Array.isArray(product.colors) ? product.colors : [],
        sizes: Array.isArray(product.sizes) ? product.sizes : [],
        silhouettePositions: Array.isArray(product.silhouettePositions)
          ? product.silhouettePositions
          : ['front'],
      };

      const [newProduct] = await db
        .insert(products)
        .values(formattedProduct)
        .returning();

      return newProduct;
    } catch (error) {
      console.error('Error creating product:', error);
      throw new Error('Failed to create product');
    }
  }

  async updateProduct(id: number, updates: Partial<Omit<Product, "id">>): Promise<Product> {
    try {
      // Ensure arrays are properly formatted
      const formattedUpdates = {
        ...updates,
        colors: updates.colors ? updates.colors : undefined,
        sizes: Array.isArray(updates.sizes) ? updates.sizes : undefined,
        silhouettePositions: Array.isArray(updates.silhouettePositions)
          ? updates.silhouettePositions
          : undefined,
      };

      const [updatedProduct] = await db
        .update(products)
        .set(formattedUpdates)
        .where(eq(products.id, id))
        .returning();

      if (!updatedProduct) {
        throw new Error('Product not found');
      }

      return updatedProduct;
    } catch (error) {
      console.error('Error updating product:', error);
      throw new Error('Failed to update product');
    }
  }

  async deleteProduct(id: number): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }

  // New methods for onboarding and rewards
  async getOnboardingSteps(): Promise<OnboardingStep[]> {
    return await db.select().from(onboardingSteps).orderBy(onboardingSteps.order);
  }

  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return await db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }

  async completeOnboardingStep(userId: number, stepId: number): Promise<void> {
    const step = await db.select().from(onboardingSteps).where(eq(onboardingSteps.id, stepId)).limit(1);
    if (!step.length) return;

    await db.insert(userProgress).values({
      userId,
      stepId,
      completed: true,
      completedAt: new Date(),
    });

    // Update user points
    await this.updateUserPoints(userId, step[0].points);
  }

  async getRewards(): Promise<Reward[]> {
    return await db.select().from(rewards);
  }

  async getUserRewards(userId: number): Promise<UserReward[]> {
    return await db.select().from(userRewards).where(eq(userRewards.userId, userId));
  }

  async claimReward(userId: number, rewardId: number): Promise<void> {
    const [reward] = await db.select().from(rewards).where(eq(rewards.id, rewardId)).limit(1);
    if (!reward) return;

    const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (!user || user.points < reward.pointsRequired) return;

    // Create expiration date (30 days from now)
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30);

    await db.insert(userRewards).values({
      userId,
      rewardId,
      claimed: true,
      claimedAt: new Date(),
      expiresAt,
    });

    // Deduct points from user
    await this.updateUserPoints(userId, -reward.pointsRequired);
  }

  async updateUserPoints(userId: number, points: number): Promise<void> {
    const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (!user) return;

    await db
      .update(users)
      .set({ points: user.points + points })
      .where(eq(users.id, userId));
  }

  // Notification methods
  async createNotification(notification: Omit<Notification, "id" | "createdAt" | "sentAt">): Promise<Notification> {
    const [newNotification] = await db
      .insert(notifications)
      .values(notification)
      .returning();

    // Send notification based on type
    switch (notification.type) {
      case 'SMS':
        await sendSMS(notification.content, notification.userId);
        break;
      case 'WHATSAPP':
        await sendWhatsAppMessage(notification.content, notification.userId);
        break;
      case 'PUSH':
        await sendPushNotification(notification.content, notification.userId);
        break;
    }

    return newNotification;
  }

  async getUserNotifications(userId: number): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(notifications.createdAt);
  }

  async markNotificationSent(notificationId: number): Promise<void> {
    await db
      .update(notifications)
      .set({
        status: 'SENT',
        sentAt: new Date()
      })
      .where(eq(notifications.id, notificationId));
  }

  // Order tracking methods
  async addOrderStatusHistory(statusHistory: Omit<OrderStatusHistory, "id" | "timestamp">): Promise<OrderStatusHistory> {
    const [newStatus] = await db
      .insert(orderStatusHistory)
      .values(statusHistory)
      .returning();

    // Create and send notification about status update
    await this.createNotification({
      userId: (await this.getOrder(statusHistory.orderId))!.userId,
      type: 'PUSH',
      content: `Sifarişinizin statusu yeniləndi: ${statusHistory.status}`,
      status: 'PENDING'
    });

    return newStatus;
  }

  async getOrderStatusHistory(orderId: number): Promise<OrderStatusHistory[]> {
    return await db
      .select()
      .from(orderStatusHistory)
      .where(eq(orderStatusHistory.orderId, orderId))
      .orderBy(orderStatusHistory.timestamp);
  }

  async updateOrderLocation(orderId: number, location: any): Promise<void> {
    await db
      .update(orders)
      .set({ currentLocation: location })
      .where(eq(orders.id, orderId));
  }

  // Push notification methods
  async savePushSubscription(subscription: Omit<PushSubscription, "id" | "createdAt">): Promise<PushSubscription> {
    const [newSubscription] = await db
      .insert(pushSubscriptions)
      .values(subscription)
      .returning();
    return newSubscription;
  }

  async getPushSubscriptions(userId: number): Promise<PushSubscription[]> {
    return await db
      .select()
      .from(pushSubscriptions)
      .where(eq(pushSubscriptions.userId, userId));
  }

  // Referral methods
  async createReferralReward(reward: Omit<ReferralReward, "id" | "createdAt">): Promise<ReferralReward> {
    const [newReward] = await db
      .insert(referralRewards)
      .values(reward)
      .returning();

    // Add points to referrer
    await this.updateUserPoints(reward.referrerId, reward.points);

    return newReward;
  }

  async getReferralRewards(userId: number): Promise<ReferralReward[]> {
    return await db
      .select()
      .from(referralRewards)
      .where(eq(referralRewards.referrerId, userId));
  }

  async generateReferralCode(userId: number): Promise<string> {
    const code = `REF${userId}${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
    await db
      .update(users)
      .set({ referralCode: code })
      .where(eq(users.id, userId));
    return code;
  }

  // Special offers methods
  async createSpecialOffer(offer: Omit<SpecialOffer, "id">): Promise<SpecialOffer> {
    const [newOffer] = await db
      .insert(specialOffers)
      .values(offer)
      .returning();
    return newOffer;
  }

  async getActiveSpecialOffers(): Promise<SpecialOffer[]> {
    const now = new Date();
    return await db
      .select()
      .from(specialOffers)
      .where(
        and(
          lte(specialOffers.startDate, now),
          gte(specialOffers.endDate, now)
        )
      );
  }

  async getUserSpecialOffers(userId: number): Promise<SpecialOffer[]> {
    const user = await this.getUser(userId);
    if (!user) return [];

    const now = new Date();
    const birthDate = user.birthDate;

    let offers = await this.getActiveSpecialOffers();

    // Filter offers based on user eligibility
    offers = offers.filter(offer => {
      if (offer.requiresVip && !user.vipStatus) return false;
      if (offer.minimumPoints && user.points < offer.minimumPoints) return false;
      if (offer.type === 'BIRTHDAY' && !birthDate) return false;

      // Check birthday month match for birthday offers
      if (offer.type === 'BIRTHDAY' && birthDate) {
        const birthMonth = birthDate.getMonth();
        const currentMonth = now.getMonth();
        return birthMonth === currentMonth;
      }

      return true;
    });

    return offers;
  }

  // Social media methods
  async createSocialMediaPost(post: Omit<SocialMediaPost, "id" | "createdAt">): Promise<SocialMediaPost> {
    const [newPost] = await db
      .insert(socialMediaPosts)
      .values(post)
      .returning();

    // Award points for social media sharing
    await this.updateUserPoints(post.userId, post.points);

    return newPost;
  }

  async getUserSocialMediaPosts(userId: number): Promise<SocialMediaPost[]> {
    return await db
      .select()
      .from(socialMediaPosts)
      .where(eq(socialMediaPosts.userId, userId));
  }

  async updateUserSocialMediaHandles(userId: number, handles: any): Promise<void> {
    await db
      .update(users)
      .set({ socialMediaHandles: handles })
      .where(eq(users.id, userId));
  }

  // Helper method to get a single order
  private async getOrder(orderId: number): Promise<Order | undefined> {
    const [order] = await db
      .select()
      .from(orders)
      .where(eq(orders.id, orderId));
    return order;
  }

  // Emoji reaction implementations
  async createEmojiReaction(reaction: InsertEmojiReaction): Promise<EmojiReaction> {
    const [newReaction] = await db
      .insert(emojiReactions)
      .values(reaction)
      .returning();
    return newReaction;
  }

  async getProductReactions(productId: number): Promise<EmojiReaction[]> {
    return await db
      .select()
      .from(emojiReactions)
      .where(eq(emojiReactions.productId, productId));
  }

  async getUserReactions(userId: number): Promise<EmojiReaction[]> {
    return await db
      .select()
      .from(emojiReactions)
      .where(eq(emojiReactions.userId, userId));
  }

  async deleteEmojiReaction(userId: number, productId: number): Promise<void> {
    await db
      .delete(emojiReactions)
      .where(
        and(
          eq(emojiReactions.userId, userId),
          eq(emojiReactions.productId, productId)
        )
      );
  }

  async getUserReferralCode(userId: number): Promise<string | null> {
    const [user] = await db
      .select({ referralCode: users.referralCode })
      .from(users)
      .where(eq(users.id, userId));
    return user?.referralCode || null;
  }

  async getReferralCount(userId: number): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(users)
      .where(eq(users.referredBy, userId));
    return result[0]?.count || 0;
  }

  async getPendingReferralCount(userId: number): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(users)
      .where(and(
        eq(users.referredBy, userId),
        eq(users.onboardingCompleted, false)
      ));
    return result[0]?.count || 0;
  }

  async getReferralPointsEarned(userId: number): Promise<number> {
    const result = await db
      .select({ sum: sql<number>`sum(points)` })
      .from(referralRewards)
      .where(eq(referralRewards.referrerId, userId));
    return result[0]?.sum || 0;
  }

  async getRecentReferrals(userId: number, limit: number): Promise<{ username: string; date: Date }[]> {
    const results = await db
      .select({
        username: users.username,
        date: users.createdAt,
      })
      .from(users)
      .where(eq(users.referredBy, userId))
      .orderBy(desc(users.createdAt))
      .limit(limit);

    return results.map(result => ({
      username: result.username,
      date: result.date
    }));
  }

  async trackReferral(referrerId: number, referredId: number): Promise<void> {
    await db
      .update(users)
      .set({ referredBy: referrerId })
      .where(eq(users.id, referredId));

    // Create referral reward with proper types
    await this.createReferralReward({
      referrerId,
      referredId,
      points: 50,
      status: 'PENDING'
    });
  }

  async getUserByReferralCode(code: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.referralCode, code));
    return user;
  }

  async getNotificationPreferences(userId: number): Promise<NotificationPreferences | undefined> {
    const [prefs] = await db
      .select()
      .from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId));
    return prefs;
  }

  async saveNotificationPreferences(userId: number, preferences: Omit<NotificationPreferences, "id">): Promise<NotificationPreferences> {
    // Check if preferences already exist
    const existingPrefs = await this.getNotificationPreferences(userId);

    if (existingPrefs) {
      // Update existing preferences
      const [updated] = await db
        .update(notificationPreferences)
        .set({ ...preferences })
        .where(eq(notificationPreferences.userId, userId))
        .returning();
      return updated;
    } else {
      // Create new preferences
      const [newPrefs] = await db
        .insert(notificationPreferences)
        .values({ ...preferences, userId })
        .returning();
      return newPrefs;
    }
  }
}

export const storage = new DatabaseStorage();