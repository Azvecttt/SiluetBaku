import { pgTable, text, serial, integer, boolean, timestamp, jsonb, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false).notNull(),
  phoneNumber: text("phone_number"),  
  email: text("email"),               
  onboardingCompleted: boolean("onboarding_completed").default(false).notNull(),
  points: integer("points").default(0).notNull(),
  birthDate: date("birth_date"),
  referralCode: text("referral_code").unique(),
  referredBy: integer("referred_by"),
  vipStatus: boolean("vip_status").default(false),
  socialMediaHandles: jsonb("social_media_handles"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  basePrice: integer("base_price").notNull(),
  sizes: text("sizes").array().default([]),
  colors: jsonb("colors").$type<Array<{ name: string; price: number; isAvailable: boolean }>>().default([]).notNull(),
  hasLipa: boolean("has_lipa").default(false),
  lipaPrice: integer("lipa_price"),
  requiresImage: boolean("requires_image").default(false).notNull(),
  description: text("description"),
  images: text("images").array().default([]),
  silhouettePositions: text("silhouette_positions").array().default(['front']),
  defaultColor: text("default_color").default('black'),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at"),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  productId: integer("product_id").notNull(),
  size: text("size"),
  color: text("color").default('black'),
  hasLipa: boolean("has_lipa").default(false),
  lipaText: text("lipa_text"),
  customerImage: text("customer_image"),
  silhouettePosition: text("silhouette_position").notNull(),
  quantity: integer("quantity").notNull(),
  totalPrice: integer("total_price").notNull(),
  status: text("status").notNull().default('pending'),
  address: text("address").notNull(),
  phoneNumber: text("phone_number").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  estimatedDeliveryTime: timestamp("estimated_delivery_time"),
  actualDeliveryTime: timestamp("actual_delivery_time"),
  currentLocation: jsonb("current_location"),
  trackingNumber: text("tracking_number"),
});

export const orderStatusHistory = pgTable("order_status_history", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  status: text("status").notNull(),
  location: jsonb("location"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  notes: text("notes"),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  content: text("content").notNull(),
  status: text("status").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  sentAt: timestamp("sent_at"),
});

export const pushSubscriptions = pgTable("push_subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  endpoint: text("endpoint").notNull(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const referralRewards = pgTable("referral_rewards", {
  id: serial("id").primaryKey(),
  referrerId: integer("referrer_id").notNull(),
  referredId: integer("referred_id").notNull(),
  points: integer("points").notNull(),
  status: text("status").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const specialOffers = pgTable("special_offers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  discountPercentage: integer("discount_percentage").notNull(),
  type: text("type").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  minimumPoints: integer("minimum_points"),
  requiresVip: boolean("requires_vip").default(false),
});

export const socialMediaPosts = pgTable("social_media_posts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  orderId: integer("order_id"),
  platform: text("platform").notNull(),
  postUrl: text("post_url").notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  points: integer("points").notNull(),
});

export const onboardingSteps = pgTable("onboarding_steps", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  points: integer("points").notNull(),
  order: integer("order").notNull(),
  icon: text("icon").notNull(),
});

export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  stepId: integer("step_id").notNull(),
  completed: boolean("completed").default(false).notNull(),
  completedAt: timestamp("completed_at"),
});

export const rewards = pgTable("rewards", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  pointsRequired: integer("points_required").notNull(),
  type: text("type").notNull(),
  value: integer("value").notNull(),
  icon: text("icon").notNull(),
});

export const userRewards = pgTable("user_rewards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  rewardId: integer("reward_id").notNull(),
  claimed: boolean("claimed").default(false).notNull(),
  claimedAt: timestamp("claimed_at"),
  expiresAt: timestamp("expires_at"),
});

export const emojiReactions = pgTable("emoji_reactions", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  userId: integer("user_id").notNull(),
  emoji: text("emoji").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const supportMessages = pgTable("support_messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  isAdmin: boolean("is_admin").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const orderTracking = pgTable("order_tracking", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  status: text("status").notNull(),
  location: jsonb("location"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  notes: text("notes"),
});

export const notificationPreferences = pgTable("notification_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  smsEnabled: boolean("sms_enabled").default(true),
  whatsappEnabled: boolean("whatsapp_enabled").default(true),
  pushEnabled: boolean("push_enabled").default(true),
  emailEnabled: boolean("email_enabled").default(true),
});

export const adminChatIds = pgTable("admin_chat_ids", {
  id: serial("id").primaryKey(),
  chatId: text("chat_id").notNull().unique(),
  username: text("username").notNull(),
  registeredAt: timestamp("registered_at").defaultNow().notNull(),
});

// Add new table for customer showcase examples
export const customerShowcase = pgTable("customer_showcase", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  image: text("image").notNull(),
  customerName: text("customer_name"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Add new table for welcome wheel rewards
export const welcomeWheelRewards = pgTable("welcome_wheel_rewards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  rewardType: text("reward_type").notNull(), // 'discount', 'free_shipping', 'free_gift_wrap', 'free_lipa'
  discountPercentage: integer("discount_percentage"),
  expiresAt: timestamp("expires_at").notNull(),
  isUsed: boolean("is_used").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Add new table for about page content
export const aboutPageContent = pgTable("about_page_content", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  type: text("type").notNull(), // 'history', 'mission', 'contact', 'location'
  order: integer("order").notNull(),
  updatedAt: timestamp("updated_at"),
});

export const insertUserSchema = createInsertSchema(users)
  .omit({
    id: true,
    isAdmin: true,
    password: true,
    onboardingCompleted: true,
    points: true,
    birthDate: true,
    referralCode: true,
    referredBy: true,
    vipStatus: true,
    socialMediaHandles: true,
    createdAt: true
  })
  .extend({
    password: z.string().min(6),
    phoneNumber: z.string().min(10).max(15).optional().nullable(),
    email: z.string().email().optional().nullable(),
    referralCode: z.string().optional(),
    birthDate: z.string().optional(),
    socialMediaHandles: z.object({
      instagram: z.string().optional(),
      facebook: z.string().optional(),
      twitter: z.string().optional(),
    }).optional(),
  });

export const insertProductSchema = createInsertSchema(products)
  .omit({ id: true, images: true, createdAt: true, updatedAt: true })
  .extend({
    sizes: z.array(z.string()).optional(),
    colors: z.array(z.object({
      name: z.string(),
      price: z.coerce.number(),
      isAvailable: z.boolean().default(true)
    })).default([{ name: 'Qara', price: 0, isAvailable: true }]),
    silhouettePositions: z.array(z.enum(['front', 'side', 'back'])).default(['front']),
    lipaPrice: z.coerce.number().optional(),
    description: z.string().optional(),
    defaultColor: z.string().default('Qara'),
    isActive: z.boolean().default(true),
  });

export const insertOrderSchema = createInsertSchema(orders)
  .omit({ 
    id: true, 
    userId: true, 
    status: true, 
    createdAt: true, 
    totalPrice: true,
    estimatedDeliveryTime: true,
    actualDeliveryTime: true,
    currentLocation: true,
    trackingNumber: true
  })
  .extend({
    phoneNumber: z.string().min(10).max(15),
    address: z.string().min(10),
    quantity: z.number().min(1),
    color: z.string(),
    silhouettePosition: z.enum(['front', 'side', 'back']),
    lipaText: z.string().optional(),
    customerImage: z.string().optional(),
    welcomeRewardId: z.number().optional(),
    referralCode: z.string().optional(),
  });

export const insertOnboardingStepSchema = createInsertSchema(onboardingSteps).omit({ id: true });

export const insertRewardSchema = createInsertSchema(rewards).omit({ id: true });

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
  sentAt: true
});

export const insertOrderStatusHistorySchema = createInsertSchema(orderStatusHistory).omit({
  id: true,
  timestamp: true
});

export const insertSocialMediaPostSchema = createInsertSchema(socialMediaPosts).omit({
  id: true,
  createdAt: true
});

export const insertEmojiReactionSchema = createInsertSchema(emojiReactions)
  .omit({ id: true, createdAt: true });

export const insertSupportMessageSchema = createInsertSchema(supportMessages).omit({
  id: true,
});

export const insertOrderTrackingSchema = createInsertSchema(orderTracking).omit({
  id: true,
  timestamp: true,
});

export const insertNotificationPreferencesSchema = createInsertSchema(notificationPreferences).omit({
  id: true,
});

// Add insert schemas for new tables
export const insertCustomerShowcaseSchema = createInsertSchema(customerShowcase)
  .omit({ id: true, createdAt: true });

export const insertWelcomeWheelRewardSchema = createInsertSchema(welcomeWheelRewards)
  .omit({ id: true, createdAt: true, isUsed: true })
  .extend({
    rewardType: z.enum(['discount', 'free_shipping']),
    discountPercentage: z.number().min(5).max(35).optional(),
    expiresAt: z.date().transform(date => new Date(date.getTime() + 3 * 24 * 60 * 60 * 1000)), // 3 days from now
  });

export const insertAboutPageContentSchema = createInsertSchema(aboutPageContent)
  .omit({ id: true, updatedAt: true })
  .extend({
    type: z.enum(['history', 'mission', 'contact', 'location']),
    order: z.number().min(1),
  });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type OnboardingStep = typeof onboardingSteps.$inferSelect;
export type UserProgress = typeof userProgress.$inferSelect;
export type Reward = typeof rewards.$inferSelect;
export type UserReward = typeof userRewards.$inferSelect;
export type OrderStatusHistory = typeof orderStatusHistory.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type PushSubscription = typeof pushSubscriptions.$inferSelect;
export type ReferralReward = typeof referralRewards.$inferSelect;
export type SpecialOffer = typeof specialOffers.$inferSelect;
export type SocialMediaPost = typeof socialMediaPosts.$inferSelect;
export type EmojiReaction = typeof emojiReactions.$inferSelect;
export type InsertEmojiReaction = z.infer<typeof insertEmojiReactionSchema>;
export type OrderTracking = typeof orderTracking.$inferSelect;
export type NotificationPreferences = typeof notificationPreferences.$inferSelect;
export type SupportMessage = typeof supportMessages.$inferSelect;
export type InsertSupportMessage = z.infer<typeof insertSupportMessageSchema>;
export type AdminChatId = typeof adminChatIds.$inferSelect;
export type InsertAdminChatId = typeof adminChatIds.$inferInsert;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

// Add new types
export type CustomerShowcase = typeof customerShowcase.$inferSelect;
export type InsertCustomerShowcase = z.infer<typeof insertCustomerShowcaseSchema>;
export type WelcomeWheelReward = typeof welcomeWheelRewards.$inferSelect;
export type InsertWelcomeWheelReward = z.infer<typeof insertWelcomeWheelRewardSchema>;
export type AboutPageContent = typeof aboutPageContent.$inferSelect;
export type InsertAboutPageContent = z.infer<typeof insertAboutPageContentSchema>;